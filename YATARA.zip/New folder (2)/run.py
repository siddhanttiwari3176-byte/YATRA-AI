"""
YATRA AI - Quick Server Launcher
Smart India Hackathon 2026 (SIH 2026 - Problem Statement SIH26204)
"""

import sys
import webbrowser
from threading import Timer
from app import app

def open_browser():
    try:
        webbrowser.open_new("http://127.0.0.1:5000/")
    except Exception:
        pass

if __name__ == "__main__":
    banner = r"""
  __   __     _  _____ ____     _         _    ___ 
  \ \ / /_ _ | |_|_   _|  _ \   / \       / \  |_ _|
   \ V / _` || __| | | | |_) | / _ \     / _ \  | | 
    | | (_| || |_  | | |  _ < / ___ \   / ___ \ | | 
    |_|\__,_| \__| |_| |_| \_/_/   \_\ /_/   \_\___|

   ==================================================
   🇮🇳 SMART INDIA HACKATHON 2026 (SIH 2026)
   Problem Statement ID: SIH26204
   Title: Student Innovation In Tourism Industries
   Theme: Travel And Tourism | Category: Software
   Team:  YATRA
   Stack: Python 3.14 + Flask 3.1 + gTTS + Leaflet.js
   ==================================================
   🚀 Starting YATRA AI Server on: http://127.0.0.1:5000/
   ==================================================
    """
    print(banner)
    
    # Auto-open browser if '--open' flag passed
    if "--open" in sys.argv:
        Timer(1.2, open_browser).start()

    app.run(host="127.0.0.1", port=5000, debug=True)
