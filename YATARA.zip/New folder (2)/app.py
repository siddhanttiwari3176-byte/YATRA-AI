"""
YATRA AI - Full-Stack Python (Flask) Web Application
Smart India Hackathon 2026 (SIH 2026)
Problem Statement ID: SIH26204 (Student Innovation In Tourism Industries)
Theme: Travel And Tourism | Category: Software | Team: YATRA
"""

import os
import secrets
from flask import Flask, render_template, request, jsonify, send_file, send_from_directory

from services.planner_service import PlannerService
from services.buddy_service import BuddyService
from services.budget_service import BudgetService
from services.chatbot_service import ChatbotService
from services.culture_service import CultureService
from services.tts_service import TTSService

app = Flask(
    __name__,
    template_folder="templates",
    static_folder="static"
)
app.secret_key = os.environ.get("SECRET_KEY", secrets.token_hex(16))

# Initialize services
buddy_service = BuddyService()


# ---------------------------------------------------------
# HTML Views
# ---------------------------------------------------------

@app.route("/")
def index():
    """Renders the main YATRA AI single-page application."""
    destinations = PlannerService.get_destinations_overview()
    gems = CultureService.get_gems("all")
    initial_phrasebook = CultureService.get_phrasebook("hi")
    initial_pools = buddy_service.list_pools("all")
    initial_budget = BudgetService.calculate_budget(6000, 3, 4, "hostel")

    return render_template(
        "index.html",
        destinations=destinations,
        gems=gems,
        phrasebook=initial_phrasebook,
        pools=initial_pools,
        budget=initial_budget
    )


# ---------------------------------------------------------
# REST API Endpoints
# ---------------------------------------------------------

@app.route("/api/destinations", methods=["GET"])
def get_destinations():
    """Returns overview of all available destinations."""
    return jsonify({
        "success": True,
        "destinations": PlannerService.get_destinations_overview()
    })


@app.route("/api/itinerary/generate", methods=["POST"])
def generate_itinerary():
    """
    Synthesizes an AI itinerary based on destination, duration, budget tier,
    vibe, and group type.
    """
    data = request.get_json() or {}
    destination = data.get("destination", "himachal")
    duration = int(data.get("duration", 3))
    budget_tier = data.get("budget_tier", "budget")
    vibe = data.get("vibe", "adventure")
    group_type = data.get("group_type", "solo")

    itinerary = PlannerService.generate_itinerary(
        destination=destination,
        duration=duration,
        budget_tier=budget_tier,
        vibe=vibe,
        group_type=group_type
    )

    return jsonify({
        "success": True,
        "itinerary": itinerary
    })


@app.route("/api/buddy-pools", methods=["GET", "POST"])
def manage_buddy_pools():
    """
    GET: List student travel pools filtered by category ('all', 'girls', 'trek', 'squad').
    POST: Create a new verified student travel pool.
    """
    if request.method == "GET":
        category = request.args.get("category", "all")
        pools = buddy_service.list_pools(category=category)
        return jsonify({
            "success": True,
            "category": category,
            "total": len(pools),
            "pools": pools
        })

    # POST: Create pool
    data = request.get_json() or {}
    creator_name = data.get("creator_name", "").strip()
    college = data.get("college", "").strip()
    destination = data.get("destination", "").strip()
    date_range = data.get("date_range", "").strip()

    if not all([creator_name, college, destination, date_range]):
        return jsonify({
            "success": False,
            "error": "Missing required fields: creator_name, college, destination, date_range."
        }), 400

    new_pool = buddy_service.create_pool(
        creator_name=creator_name,
        college=college,
        destination=destination,
        date_range=date_range,
        pool_type=data.get("pool_type", "College Squad"),
        seats_total=int(data.get("seats_total", 4)),
        cost_estimate=data.get("cost_estimate", "Split equally"),
        gender_pref=data.get("gender_pref", "Open to All Students"),
        description=data.get("description", "")
    )

    return jsonify({
        "success": True,
        "message": "Student travel pool created successfully!",
        "pool": new_pool
    }), 201


@app.route("/api/buddy-pools/<pool_id>/join", methods=["POST"])
def join_buddy_pool(pool_id):
    """Requests to join an existing student travel pool."""
    res = buddy_service.join_pool(pool_id)
    if res is None:
        return jsonify({"success": False, "error": "Pool not found"}), 404
    return jsonify(res)


@app.route("/api/budget/calculate", methods=["POST"])
def calculate_budget():
    """Calculates granular student budget breakdown and per-student split share."""
    data = request.get_json() or {}
    total_budget = float(data.get("total_budget", 6000))
    travelers = int(data.get("travelers", 3))
    days = int(data.get("days", 4))
    stay_type = data.get("stay_type", "hostel")

    result = BudgetService.calculate_budget(
        total_budget=total_budget,
        travelers=travelers,
        days=days,
        stay_type=stay_type
    )

    return jsonify({
        "success": True,
        "budget": result
    })


@app.route("/api/chat", methods=["POST"])
def chat():
    """Conversational endpoint for Yatra Bot AI assistant."""
    data = request.get_json() or {}
    user_message = data.get("message", "").strip()

    if not user_message:
        return jsonify({
            "success": False,
            "error": "Message cannot be empty."
        }), 400

    bot_reply = ChatbotService.answer_query(user_message)
    return jsonify({
        "success": True,
        "reply": bot_reply
    })


@app.route("/api/culture/gems", methods=["GET"])
def get_culture_gems():
    """Returns indigenous artisan profiles and hidden heritage spots."""
    category = request.args.get("category", "all")
    gems = CultureService.get_gems(category=category)
    return jsonify({
        "success": True,
        "category": category,
        "gems": gems
    })


@app.route("/api/culture/phrasebook", methods=["GET"])
def get_phrasebook():
    """Returns travel phrasebook for a selected language ('hi', 'ta', 'bn', 'mr', 'gu')."""
    lang = request.args.get("lang", "hi")
    phrasebook = CultureService.get_phrasebook(lang_code=lang)
    return jsonify({
        "success": True,
        "lang": lang,
        "phrasebook": phrasebook
    })


@app.route("/api/tts/audio", methods=["GET"])
def stream_tts_audio():
    """Generates and streams MP3 speech audio via Python gTTS."""
    text = request.args.get("text", "").strip()
    lang = request.args.get("lang", "hi").strip()

    if not text:
        return jsonify({"success": False, "error": "Text parameter is required."}), 400

    fp = TTSService.generate_speech_audio(text, lang_code=lang)
    if fp is None:
        return jsonify({"success": False, "error": "TTS audio synthesis failed or offline."}), 503

    return send_file(
        fp,
        mimetype="audio/mpeg",
        as_attachment=False,
        download_name="phrase.mp3"
    )


@app.route("/api/edupass/verify", methods=["POST"])
def verify_edupass():
    """Simulates DigiLocker/University ID student verification."""
    data = request.get_json() or {}
    student_name = data.get("student_name", "").strip()
    college_name = data.get("college_name", "").strip()
    student_id = data.get("student_id", "").strip()

    if not all([student_name, college_name, student_id]):
        return jsonify({"success": False, "error": "All verification fields are required."}), 400

    return jsonify({
        "success": True,
        "verified": True,
        "student_name": student_name,
        "college_name": college_name,
        "student_id": student_id,
        "discount_rate": 0.20,
        "badge": "Verified Student (EduPass)",
        "message": f"Welcome, {student_name}! EduPass student travel concessions activated for {college_name}."
    })


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"🚀 [YATRA AI] Starting Flask server on http://127.0.0.1:{port}")
    app.run(host="0.0.0.0", port=port, debug=True)
