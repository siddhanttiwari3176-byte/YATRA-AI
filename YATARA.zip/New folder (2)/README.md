# 🇮🇳 YATRA AI - Student Innovation in Tourism Industries

> **Smart India Hackathon 2026 (SIH 2026)**  
> **Problem Statement ID:** SIH26204  
> **Problem Title:** Student Innovation In Tourism Industries  
> **Theme:** Travel And Tourism  
> **Category:** Software  
> **Team Name:** YATRA  
> **Backend Architecture:** Python 3.14 + Flask 3.1 + gTTS + Jinja2  

---

## 🌟 Executive Summary

**YATRA AI** is a full-stack Python web application and travel intelligence platform engineered specifically for university students and budget backpackers in India. Built for the **Smart India Hackathon 2026**, it combines:

1. **Python AI Itinerary Engine (`services/planner_service.py`)**: Synthesizes personalized multi-day itineraries, computes student concessions, carbon footprints, and GPS coordinates.
2. **Interactive Leaflet.js Mapping**: Dynamically visualizes travel routes, waypoints, day stops, and youth hostels directly from Flask JSON endpoints.
3. **Student Travel Pool & Buddy Finder (`services/buddy_service.py`)**: Thread-safe pool service to split transit (tempo travelers, shared cabs) and accommodation costs with verified students.
4. **Smart Budget Tracker (`services/budget_service.py`)**: Real-time Chart.js donut expense allocation across Stays, Transit, Food, Activities, and Emergency safety reserves.
5. **Vocal for Local Culture Hub (`services/culture_service.py`)**: Curated showcase of indigenous artisans (Channapatna toys, Majuli masks, Chettinad architecture).
6. **Multi-Language Speech Synthesis (`services/tts_service.py`)**: Streams real-time audio pronunciation across 5 Indian languages (**Hindi, Tamil, Bengali, Marathi, Gujarati**) using Python `gTTS` (Google Text-to-Speech).
7. **Yatra Bot 24x7 AI (`services/chatbot_service.py`)**: Conversational assistant with instant tourist hacks and 1-tap SOS routing to the **National Tourism Helpline 1363** and **112**.

---

## 🚀 REST API Reference

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/` | Renders full web app via Jinja2 template (`templates/index.html`). |
| `GET` | `/api/destinations` | Returns available Indian destination overviews and coordinates. |
| `POST` | `/api/itinerary/generate` | Generates custom day-by-day schedule, student perks, and waypoints. |
| `GET` | `/api/buddy-pools` | Lists student travel pools filtered by category (`all`, `girls`, `trek`, `squad`). |
| `POST` | `/api/buddy-pools` | Creates a new verified student travel pool. |
| `POST` | `/api/buddy-pools/<id>/join`| Requests to join a pool and decrements open seats. |
| `POST` | `/api/budget/calculate` | Calculates budget breakdown and per-student daily share. |
| `POST` | `/api/chat` | AI conversational endpoint with emergency SOS triggers. |
| `GET` | `/api/culture/gems` | Returns artisan profiles filterable by category. |
| `GET` | `/api/culture/phrasebook`| Returns phrasebook for requested language (`hi`, `ta`, `bn`, `mr`, `gu`). |
| `GET` | `/api/tts/audio` | Streams live generated MP3 speech audio via Python `gTTS`. |
| `POST` | `/api/edupass/verify` | Simulates college enrollment verification and returns 20% discount token. |

---

## 📂 Project Structure

```text
PROJECT/
├── app.py                      # Main Flask application & route controllers
├── run.py                      # Quick server launcher with branded banner
├── test_app.py                 # Automated Python unit test suite (8 tests)
├── requirements.txt            # Python dependencies (Flask, gTTS, etc.)
├── README.md                   # Complete documentation
├── services/
│   ├── __init__.py
│   ├── planner_service.py      # AI Itinerary synthesis & destination dataset
│   ├── buddy_service.py        # Student travel pool manager
│   ├── budget_service.py       # Expense breakdown & group calculations
│   ├── chatbot_service.py      # Yatra Bot NLP & emergency SOS triggers
│   ├── culture_service.py      # Artisans, hidden gems & phrasebooks
│   └── tts_service.py          # gTTS server-side audio generation
├── templates/
│   └── index.html              # Dynamic Jinja2 template with Tailwind CSS
└── static/
    ├── css/
    │   └── custom.css          # Design system & Leaflet marker styles
    └── js/
        └── app.js              # Client controller connecting to Flask REST APIs
```

---

## ⚡ How to Run

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the Server
```bash
python run.py
# or simply:
python app.py
```
Visit **`http://127.0.0.1:5000/`** in your browser!

### 3. Run Automated Tests
```bash
python test_app.py
```
*(All 8 test suites validate the API endpoints, calculations, and templates).*

---
*Developed with pride for **Smart India Hackathon 2026** by **Team YATRA**.*
