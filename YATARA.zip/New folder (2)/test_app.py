"""
YATRA AI - Automated Python Test Suite
Validates all Flask routes, REST APIs, AI Itinerary generator,
Buddy Pool operations, and Budget calculator.
"""

import unittest
import json
from app import app, buddy_service
from services.planner_service import PlannerService
from services.budget_service import BudgetService
from services.chatbot_service import ChatbotService
from services.culture_service import CultureService

class YatraAITestCase(unittest.TestCase):
    def setUp(self):
        app.config["TESTING"] = True
        self.client = app.test_client()

    def test_01_index_page(self):
        """Verify the main Jinja2 template renders with HTTP 200."""
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        html = response.get_data(as_text=True)
        self.assertIn("YATRA", html)
        self.assertIn("SIH26204", html)
        self.assertIn("Smart India Hackathon", html)

    def test_02_destinations_api(self):
        """Verify GET /api/destinations returns destination overviews."""
        response = self.client.get("/api/destinations")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertTrue(data["success"])
        self.assertGreaterEqual(len(data["destinations"]), 4)

    def test_03_itinerary_generation(self):
        """Verify POST /api/itinerary/generate synthesizes custom multi-day plans."""
        payload = {
            "destination": "hampi",
            "duration": 2,
            "budget_tier": "budget",
            "vibe": "heritage",
            "group_type": "squad"
        }
        response = self.client.post(
            "/api/itinerary/generate",
            data=json.dumps(payload),
            content_type="application/json"
        )
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertTrue(data["success"])
        itinerary = data["itinerary"]
        self.assertEqual(itinerary["destination_key"], "hampi")
        self.assertEqual(itinerary["duration"], 2)
        self.assertEqual(len(itinerary["days"]), 2)
        self.assertGreater(itinerary["estimated_cost_per_student"], 0)
        self.assertEqual(len(itinerary["waypoints"]), 2)

    def test_04_buddy_pools_crud(self):
        """Verify Buddy Pool listing, creation, and joining."""
        # 1. List
        list_res = self.client.get("/api/buddy-pools?category=all")
        self.assertEqual(list_res.status_code, 200)
        list_data = list_res.get_json()
        self.assertTrue(list_data["success"])
        initial_count = len(list_data["pools"])

        # 2. Create
        new_pool_payload = {
            "creator_name": "Test Student",
            "college": "IIT Bombay",
            "destination": "Spiti Valley Circuit",
            "date_range": "Nov 10 - Nov 15",
            "pool_type": "College Squad",
            "seats_total": 4,
            "cost_estimate": "₹900/seat",
            "gender_pref": "Open to All Students",
            "description": "Splitting cab from Chandigarh!"
        }
        create_res = self.client.post(
            "/api/buddy-pools",
            data=json.dumps(new_pool_payload),
            content_type="application/json"
        )
        self.assertEqual(create_res.status_code, 201)
        created = create_res.get_json()["pool"]
        self.assertEqual(created["creator_name"], "Test Student")
        self.assertEqual(created["seats_left"], 3)
        new_pool_id = created["id"]

        # 3. Join
        join_res = self.client.post(f"/api/buddy-pools/{new_pool_id}/join")
        self.assertEqual(join_res.status_code, 200)
        join_data = join_res.get_json()
        self.assertTrue(join_data["success"])
        self.assertEqual(join_data["seats_left"], 2)

    def test_05_budget_calculator_api(self):
        """Verify POST /api/budget/calculate computes correct allocations and totals."""
        payload = {
            "total_budget": 9000,
            "travelers": 3,
            "days": 5,
            "stay_type": "homestay"
        }
        response = self.client.post(
            "/api/budget/calculate",
            data=json.dumps(payload),
            content_type="application/json"
        )
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertTrue(data["success"])
        budget = data["budget"]
        self.assertEqual(budget["per_student_share"], 3000)
        self.assertEqual(budget["per_student_daily"], 600)
        self.assertIn("chart_data", budget)
        self.assertEqual(len(budget["chart_data"]["values"]), 5)

    def test_06_chatbot_api(self):
        """Verify POST /api/chat answers general queries and triggers emergency SOS."""
        # Normal query
        res_hi = self.client.post(
            "/api/chat",
            data=json.dumps({"message": "Hello"}),
            content_type="application/json"
        )
        self.assertEqual(res_hi.status_code, 200)
        self.assertIn("Yatra Bot", res_hi.get_json()["reply"]["response"])

        # Emergency SOS trigger
        res_sos = self.client.post(
            "/api/chat",
            data=json.dumps({"message": "I need emergency help police"}),
            content_type="application/json"
        )
        self.assertEqual(res_sos.status_code, 200)
        data_sos = res_sos.get_json()["reply"]
        self.assertTrue(data_sos["is_sos"])
        self.assertIn("1363", data_sos["response"])
        self.assertIn("112", data_sos["response"])

    def test_07_culture_and_phrasebook(self):
        """Verify Culture Gems and Multilingual Phrasebook endpoints."""
        gems_res = self.client.get("/api/culture/gems?category=Indigenous Artisans")
        self.assertEqual(gems_res.status_code, 200)
        self.assertTrue(len(gems_res.get_json()["gems"]) > 0)

        phrase_res = self.client.get("/api/culture/phrasebook?lang=ta")
        self.assertEqual(phrase_res.status_code, 200)
        self.assertEqual(phrase_res.get_json()["phrasebook"]["name"], "Tamil (தமிழ்)")

    def test_08_edupass_verification(self):
        """Verify POST /api/edupass/verify confirms student enrollment."""
        payload = {
            "student_name": "Siddhant Tiwari",
            "college_name": "National Institute of Technology",
            "student_id": "SIH-2026-STU-042"
        }
        res = self.client.post(
            "/api/edupass/verify",
            data=json.dumps(payload),
            content_type="application/json"
        )
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data["verified"])
        self.assertEqual(data["discount_rate"], 0.20)

if __name__ == "__main__":
    unittest.main()
