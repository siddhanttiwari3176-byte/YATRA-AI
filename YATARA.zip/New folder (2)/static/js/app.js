/**
 * YATRA AI - Client Application Controller (Flask Integration)
 * Seamlessly interfaces with Python REST endpoints for AI Itinerary, Buddy Pools,
 * Budget Calculations, Chatbot NLP, and gTTS Audio streaming.
 */

const YatraApp = {
  activeLanguage: 'hi',
  isStudentVerified: false,
  verifiedStudentData: null,
  map: null,
  markersGroup: null,
  routeLine: null,
  chartInstance: null,

  init() {
    this.initMap();
    this.bindNavigation();
    this.bindHeroSearch();
    this.bindPlannerForm();
    this.bindCultureFilters();
    this.bindPhrasebookLanguages();
    this.bindBuddyPools();
    this.bindBudgetCalculator();
    this.bindChatbot();
    this.bindEduPassModal();

    // Trigger initial calculation
    this.updateBudgetBreakdown();
  },

  // -------------------------------------------------------------
  // Toast Notifications
  // -------------------------------------------------------------
  showToast(message, type = 'info') {
    const toast = document.getElementById('toastNotification');
    const toastMsg = document.getElementById('toastMessage');
    const toastIcon = document.getElementById('toastIcon');
    if (!toast || !toastMsg) return;

    toastMsg.textContent = message;

    if (type === 'success') {
      toast.className = 'fixed bottom-5 left-1/2 -translate-x-1/2 z-50 bg-emerald-900 text-emerald-100 px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border border-emerald-500/40 text-sm font-medium transition-all duration-300';
      if (toastIcon) toastIcon.className = 'fas fa-circle-check text-emerald-400 text-base';
    } else if (type === 'error') {
      toast.className = 'fixed bottom-5 left-1/2 -translate-x-1/2 z-50 bg-red-900 text-red-100 px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border border-red-500/40 text-sm font-medium transition-all duration-300';
      if (toastIcon) toastIcon.className = 'fas fa-circle-exclamation text-red-400 text-base';
    } else {
      toast.className = 'fixed bottom-5 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-slate-100 px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border border-slate-700 text-sm font-medium transition-all duration-300';
      if (toastIcon) toastIcon.className = 'fas fa-info-circle text-orange-400 text-base';
    }

    toast.classList.remove('hidden', 'opacity-0', 'translate-y-4');
    toast.classList.add('opacity-100', 'translate-y-0');

    setTimeout(() => {
      toast.classList.add('opacity-0', 'translate-y-4');
      setTimeout(() => toast.classList.add('hidden'), 300);
    }, 4000);
  },

  // -------------------------------------------------------------
  // Navigation & Smooth Scroll
  // -------------------------------------------------------------
  bindNavigation() {
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const mobileNav = document.getElementById('mobileNav');
    if (mobileMenuBtn && mobileNav) {
      mobileMenuBtn.addEventListener('click', () => {
        mobileNav.classList.toggle('hidden');
      });
    }

    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', (e) => {
        if (mobileNav) mobileNav.classList.add('hidden');
        const targetId = e.currentTarget.getAttribute('href');
        if (targetId && targetId.startsWith('#')) {
          const targetElem = document.querySelector(targetId);
          if (targetElem) {
            e.preventDefault();
            targetElem.scrollIntoView({ behavior: 'smooth' });
          }
        }
      });
    });
  },

  // -------------------------------------------------------------
  // Leaflet.js Mapping Controller
  // -------------------------------------------------------------
  initMap() {
    const mapContainer = document.getElementById('itineraryMap');
    if (!mapContainer || typeof L === 'undefined') return;

    this.map = L.map('itineraryMap', {
      center: [22.3511, 78.6677],
      zoom: 5,
      zoomControl: true,
      scrollWheelZoom: false
    });

    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
      subdomains: 'abcd',
      maxZoom: 19
    }).addTo(this.map);

    this.markersGroup = L.featureGroup().addTo(this.map);
  },

  updateMapWaypoints(destinationName, days) {
    if (!this.map || !this.markersGroup) return;

    this.markersGroup.clearLayers();
    if (this.routeLine) {
      this.map.removeLayer(this.routeLine);
      this.routeLine = null;
    }

    const latLngs = [];
    days.forEach((dayData, idx) => {
      const dayNum = idx + 1;
      const coords = dayData.coords;
      latLngs.push(coords);

      const customIcon = L.divIcon({
        className: 'custom-map-marker-container',
        html: `<div class="custom-map-marker" style="width: 34px; height: 34px;">${dayNum}</div>`,
        iconSize: [34, 34],
        iconAnchor: [17, 17],
        popupAnchor: [0, -18]
      });

      const marker = L.marker(coords, { icon: customIcon });
      const popupHtml = `
        <div class="p-3 max-w-xs text-slate-800">
          <div class="bg-orange-500 text-white font-bold text-xs uppercase px-2 py-0.5 rounded-full inline-block mb-1">
            Day ${dayNum} Stop
          </div>
          <h4 class="font-bold text-sm mb-1">${dayData.title}</h4>
          <div class="text-xs text-slate-600 space-y-1 mb-2">
            <p><strong>AM:</strong> ${dayData.morning.activity.slice(0, 75)}...</p>
            <p><strong>PM:</strong> ${dayData.afternoon.activity.slice(0, 75)}...</p>
          </div>
          <div class="bg-teal-50 text-teal-800 text-[11px] p-1.5 rounded font-medium">
            🎯 ${dayData.morning.student_perk}
          </div>
        </div>
      `;
      marker.bindPopup(popupHtml);
      this.markersGroup.addLayer(marker);
    });

    if (latLngs.length > 1) {
      this.routeLine = L.polyline(latLngs, {
        color: '#FF6500',
        weight: 4,
        opacity: 0.8,
        dashArray: '8, 8'
      }).addTo(this.map);
    }

    if (latLngs.length > 0) {
      if (latLngs.length === 1) {
        this.map.setView(latLngs[0], 12);
      } else {
        this.map.fitBounds(this.markersGroup.getBounds().pad(0.35));
      }
    }
  },

  focusDayOnMap(coords) {
    if (!this.map || !coords) return;
    this.map.flyTo(coords, 14, { animate: true, duration: 1.2 });
  },

  // -------------------------------------------------------------
  // Hero Natural Search & Quick Chips
  // -------------------------------------------------------------
  bindHeroSearch() {
    const searchForm = document.getElementById('heroSearchForm');
    const searchInput = document.getElementById('heroSearchInput');

    if (searchForm && searchInput) {
      searchForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const query = searchInput.value.trim().toLowerCase();
        if (!query) return;

        let matchedKey = 'himachal';
        if (query.includes('hampi') || query.includes('karnataka')) matchedKey = 'hampi';
        else if (query.includes('varanasi') || query.includes('kashi')) matchedKey = 'varanasi';
        else if (query.includes('rishikesh') || query.includes('rafting')) matchedKey = 'rishikesh';
        else if (query.includes('meghalaya') || query.includes('shillong')) matchedKey = 'meghalaya';
        else if (query.includes('gokarna') || query.includes('beach')) matchedKey = 'gokarna';

        const destSelect = document.getElementById('planDestination');
        if (destSelect) destSelect.value = matchedKey;

        document.getElementById('planner')?.scrollIntoView({ behavior: 'smooth' });
        this.generateItineraryFromBackend();
      });
    }

    document.querySelectorAll('.hero-search-chip').forEach(chip => {
      chip.addEventListener('click', (e) => {
        const query = e.currentTarget.dataset.query;
        if (searchInput) searchInput.value = query;
        searchForm?.dispatchEvent(new Event('submit'));
      });
    });

    document.querySelectorAll('.dest-quick-chip').forEach(chip => {
      chip.addEventListener('click', (e) => {
        const destKey = e.currentTarget.dataset.dest;
        const destSelect = document.getElementById('planDestination');
        if (destSelect) destSelect.value = destKey;
        document.getElementById('planner')?.scrollIntoView({ behavior: 'smooth' });
        this.generateItineraryFromBackend();
      });
    });
  },

  // -------------------------------------------------------------
  // AI Itinerary Planner (Python Backend Endpoint)
  // -------------------------------------------------------------
  bindPlannerForm() {
    const form = document.getElementById('plannerForm');
    const durationInput = document.getElementById('planDuration');
    const durationVal = document.getElementById('durationVal');

    if (durationInput && durationVal) {
      durationInput.addEventListener('input', (e) => {
        durationVal.textContent = `${e.target.value} ${e.target.value === '1' ? 'Day' : 'Days'}`;
      });
    }

    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        this.generateItineraryFromBackend();
      });
    }
  },

  async generateItineraryFromBackend() {
    const dest = document.getElementById('planDestination')?.value || 'himachal';
    const duration = parseInt(document.getElementById('planDuration')?.value || '3', 10);
    const budgetTier = document.getElementById('planBudget')?.value || 'budget';
    const vibe = document.getElementById('planVibe')?.value || 'adventure';
    const group = document.getElementById('planGroup')?.value || 'solo';

    const loadingElem = document.getElementById('plannerLoading');
    const outputElem = document.getElementById('plannerOutput');
    const emptyElem = document.getElementById('plannerEmpty');

    if (emptyElem) emptyElem.classList.add('hidden');
    if (outputElem) outputElem.classList.add('hidden');
    if (loadingElem) loadingElem.classList.remove('hidden');

    try {
      const response = await fetch('/api/itinerary/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          destination: dest,
          duration: duration,
          budget_tier: budgetTier,
          vibe: vibe,
          group_type: group
        })
      });

      const data = await response.json();
      if (!data.success) throw new Error(data.error || 'Failed to generate plan');

      const plan = data.itinerary;
      this.renderItineraryResult(plan);

    } catch (err) {
      console.error(err);
      this.showToast('Could not reach Python AI server. Please try again.', 'error');
    } finally {
      if (loadingElem) loadingElem.classList.add('hidden');
      if (outputElem) outputElem.classList.remove('hidden');
    }
  },

  renderItineraryResult(plan) {
    const summaryContainer = document.getElementById('itineraryHeaderSummary');
    const timelineContainer = document.getElementById('timelineSchedule');

    if (summaryContainer) {
      summaryContainer.innerHTML = `
        <div class="bg-gradient-to-r from-slate-900 to-teal-950 text-white p-6 rounded-2xl shadow-xl mb-6 relative overflow-hidden">
          <div class="absolute right-0 top-0 translate-x-4 -translate-y-4 w-44 h-44 bg-orange-500/10 rounded-full blur-2xl"></div>
          
          <div class="flex flex-wrap items-center justify-between gap-4 mb-3">
            <div>
              <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-orange-500/20 text-orange-400 border border-orange-500/30">
                <i class="fas fa-sparkles"></i> AI Generated Itinerary • ${plan.vibe}
              </span>
              <h3 class="text-2xl lg:text-3xl font-bold mt-2 text-white font-heading">${plan.destination_name}</h3>
              <p class="text-slate-300 text-sm mt-1 max-w-2xl">${plan.tagline}</p>
            </div>
            
            <div class="text-right bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/15">
              <div class="text-xs uppercase tracking-wider text-slate-300 font-medium">Estimated Per Student</div>
              <div class="text-3xl font-extrabold text-orange-400">₹${plan.estimated_cost_per_student.toLocaleString('en-IN')}</div>
              <div class="text-[11px] text-teal-300 mt-0.5">Save approx. ₹${plan.student_savings} with EduPass</div>
            </div>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-white/10 text-xs">
            <div class="flex items-center gap-2">
              <span class="p-2 bg-white/10 rounded-lg text-orange-400"><i class="fas fa-calendar-day"></i></span>
              <div>
                <p class="text-slate-400">Duration</p>
                <p class="font-bold text-white">${plan.duration} ${plan.duration === 1 ? 'Day' : 'Days'}</p>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <span class="p-2 bg-white/10 rounded-lg text-teal-400"><i class="fas fa-wallet"></i></span>
              <div>
                <p class="text-slate-400">Tier & Group</p>
                <p class="font-bold text-white">${plan.tier_label} (${plan.group_savings_label})</p>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <span class="p-2 bg-white/10 rounded-lg text-emerald-400"><i class="fas fa-leaf"></i></span>
              <div>
                <p class="text-slate-400">Eco-Score</p>
                <p class="font-bold text-emerald-300">${plan.carbon_score}</p>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <span class="p-2 bg-white/10 rounded-lg text-amber-400"><i class="fas fa-id-card"></i></span>
              <div>
                <p class="text-slate-400">Student Status</p>
                <p class="font-bold text-amber-300">Verified Concessions Active</p>
              </div>
            </div>
          </div>

          <div class="mt-4 p-3 bg-orange-500/15 border border-orange-500/30 rounded-xl text-xs text-orange-200 flex items-center gap-2">
            <i class="fas fa-lightbulb text-orange-400 text-sm"></i>
            <span><strong>Smart Travel Tip:</strong> ${plan.student_tips}</span>
          </div>
        </div>
      `;
    }

    if (timelineContainer) {
      timelineContainer.innerHTML = '';

      plan.days.forEach((dayData, index) => {
        const dayNum = index + 1;
        const dayCard = document.createElement('div');
        dayCard.className = 'relative pl-8 pb-8 border-l-2 border-orange-200 last:border-transparent group';

        dayCard.innerHTML = `
          <div class="absolute -left-[17px] top-0 w-8 h-8 rounded-full bg-gradient-to-br from-orange-500 to-amber-500 text-white font-bold flex items-center justify-center text-xs shadow-md group-hover:scale-110 transition-transform">
            ${dayNum}
          </div>

          <div class="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
            <div class="flex flex-wrap items-center justify-between gap-2 mb-3">
              <h4 class="text-lg font-bold text-slate-900 font-heading">Day ${dayNum}: ${dayData.title}</h4>
              <button onclick="YatraApp.focusDayOnMap([${dayData.coords.join(',')}])" 
                class="inline-flex items-center gap-1 text-xs font-semibold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-lg hover:bg-teal-100 transition-colors">
                <i class="fas fa-map-marker-alt"></i> View on Map
              </button>
            </div>

            <div class="space-y-3 text-sm">
              <div class="p-3.5 rounded-xl bg-orange-50/50 border border-orange-100/80">
                <div class="flex items-center justify-between text-xs font-semibold text-orange-700 mb-1">
                  <span class="flex items-center gap-1.5"><i class="fas fa-sun text-amber-500"></i> Morning • ${dayData.morning.time}</span>
                  <span class="bg-white px-2 py-0.5 rounded shadow-2xs font-bold text-slate-700">${dayData.morning.cost}</span>
                </div>
                <p class="text-slate-800 text-xs leading-relaxed">${dayData.morning.activity}</p>
                <div class="mt-2 text-[11px] text-teal-800 font-medium flex items-center gap-1">
                  <i class="fas fa-tag text-teal-600"></i> ${dayData.morning.student_perk}
                </div>
              </div>

              <div class="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70">
                <div class="flex items-center justify-between text-xs font-semibold text-slate-700 mb-1">
                  <span class="flex items-center gap-1.5"><i class="fas fa-cloud-sun text-orange-500"></i> Afternoon • ${dayData.afternoon.time}</span>
                  <span class="bg-white px-2 py-0.5 rounded shadow-2xs font-bold text-slate-700">${dayData.afternoon.cost}</span>
                </div>
                <p class="text-slate-800 text-xs leading-relaxed">${dayData.afternoon.activity}</p>
                <div class="mt-2 text-[11px] text-teal-800 font-medium flex items-center gap-1">
                  <i class="fas fa-tag text-teal-600"></i> ${dayData.afternoon.student_perk}
                </div>
              </div>

              <div class="p-3.5 rounded-xl bg-slate-900 text-white">
                <div class="flex items-center justify-between text-xs font-semibold text-orange-400 mb-1">
                  <span class="flex items-center gap-1.5"><i class="fas fa-moon text-amber-300"></i> Evening • ${dayData.evening.time}</span>
                  <span class="bg-white/15 px-2 py-0.5 rounded font-bold text-white">${dayData.evening.cost}</span>
                </div>
                <p class="text-slate-300 text-xs leading-relaxed">${dayData.evening.activity}</p>
                <div class="mt-2 text-[11px] text-teal-300 font-medium flex items-center gap-1">
                  <i class="fas fa-star text-amber-400"></i> ${dayData.evening.student_perk}
                </div>
              </div>
            </div>
          </div>
        `;

        timelineContainer.appendChild(dayCard);
      });
    }

    // Update map waypoints
    this.updateMapWaypoints(plan.destination_name, plan.days);
  },

  // -------------------------------------------------------------
  // Culture Hub & Phrasebook
  // -------------------------------------------------------------
  bindCultureFilters() {
    const buttons = document.querySelectorAll('.culture-filter-btn');
    buttons.forEach(btn => {
      btn.addEventListener('click', async (e) => {
        buttons.forEach(b => {
          b.classList.remove('bg-orange-600', 'text-white');
          b.classList.add('bg-white', 'text-slate-700', 'border', 'border-slate-200');
        });
        e.currentTarget.classList.add('bg-orange-600', 'text-white');
        e.currentTarget.classList.remove('bg-white', 'text-slate-700', 'border', 'border-slate-200');

        const cat = e.currentTarget.dataset.category;
        await this.fetchAndRenderCultureGems(cat);
      });
    });
  },

  async fetchAndRenderCultureGems(category) {
    try {
      const response = await fetch(`/api/culture/gems?category=${encodeURIComponent(category)}`);
      const data = await response.json();
      if (!data.success) return;

      const container = document.getElementById('culturalGemsContainer');
      if (!container) return;
      container.innerHTML = '';

      data.gems.forEach(gem => {
        const card = document.createElement('div');
        card.className = 'group bg-white rounded-2xl overflow-hidden border border-slate-200/80 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between';

        card.innerHTML = `
          <div>
            <div class="relative h-48 overflow-hidden">
              <img src="${gem.image}" alt="${gem.name}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
              <div class="absolute top-3 left-3 flex flex-col gap-1">
                <span class="bg-slate-900/80 backdrop-blur-md text-white text-[11px] font-semibold px-2.5 py-1 rounded-full">
                  ${gem.category}
                </span>
                <span class="bg-orange-600/90 backdrop-blur-md text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                  ${gem.badge}
                </span>
              </div>
            </div>

            <div class="p-5">
              <div class="text-xs font-semibold text-teal-700 mb-1">
                <i class="fas fa-location-dot mr-1"></i> ${gem.location}
              </div>
              <h4 class="text-lg font-bold text-slate-900 mb-2 font-heading">${gem.name}</h4>
              <p class="text-xs text-slate-600 leading-relaxed mb-3">${gem.description}</p>
              
              <div class="p-2.5 rounded-xl bg-orange-50 border border-orange-100 text-[11px] text-orange-900 mb-2">
                <strong>🎓 Student & Community Impact:</strong> ${gem.student_impact}
              </div>
            </div>
          </div>

          <div class="px-5 pb-5 pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
            <div>
              <span class="text-slate-400 block text-[10px]">Student Access</span>
              <span class="font-bold text-slate-800">${gem.price}</span>
            </div>
            <button onclick="YatraApp.showArtisanModal('${gem.name}', '${gem.category}', '${gem.location}', '${gem.contact}')" 
              class="px-3 py-1.5 rounded-xl bg-slate-900 text-white hover:bg-orange-600 transition-colors font-semibold text-xs cursor-pointer">
              Connect →
            </button>
          </div>
        `;
        container.appendChild(card);
      });
    } catch (err) {
      console.error(err);
    }
  },

  showArtisanModal(name, category, location, contact) {
    const modal = document.getElementById('artisanConnectModal');
    const content = document.getElementById('artisanModalContent');
    if (!modal || !content) return;

    content.innerHTML = `
      <div class="text-center mb-4">
        <span class="text-xs font-bold uppercase tracking-wider text-orange-600">${category}</span>
        <h3 class="text-xl font-bold text-slate-900 mt-1 font-heading">${name}</h3>
        <p class="text-xs text-slate-500">${location}</p>
      </div>

      <div class="space-y-3 text-xs text-slate-700 bg-slate-50 p-4 rounded-xl mb-4">
        <p><strong>Official Contact / Guild:</strong> ${contact}</p>
        <p><strong>Student Concession:</strong> Free or 50% discount upon showing valid College ID.</p>
        <p><strong>Vocal For Local Initiative:</strong> All booking tokens are routed directly with 0% platform commission to support indigenous artisans.</p>
      </div>

      <div class="flex gap-2">
        <a href="tel:${contact.replace(/[^0-9]/g, '')}" class="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold text-xs text-center">
          <i class="fas fa-phone mr-1"></i> Call Guild
        </a>
        <button onclick="document.getElementById('artisanConnectModal').classList.add('hidden')" class="flex-1 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl font-semibold text-xs cursor-pointer">
          Close
        </button>
      </div>
    `;

    modal.classList.remove('hidden');
  },

  bindPhrasebookLanguages() {
    const langBtns = document.querySelectorAll('.phrase-lang-btn');
    langBtns.forEach(btn => {
      btn.addEventListener('click', async (e) => {
        langBtns.forEach(b => {
          b.classList.remove('bg-slate-900', 'text-white');
          b.classList.add('bg-slate-100', 'text-slate-700');
        });
        e.currentTarget.classList.add('bg-slate-900', 'text-white');
        e.currentTarget.classList.remove('bg-slate-100', 'text-slate-700');

        const langCode = e.currentTarget.dataset.lang;
        this.activeLanguage = langCode;
        await this.fetchAndRenderPhrasebook(langCode);
      });
    });
  },

  async fetchAndRenderPhrasebook(langCode) {
    try {
      const response = await fetch(`/api/culture/phrasebook?lang=${langCode}`);
      const data = await response.json();
      if (!data.success) return;

      const phrasebook = data.phrasebook;
      const greetingContainer = document.getElementById('phraseGreeting');
      const listContainer = document.getElementById('phrasebookList');

      if (greetingContainer) {
        greetingContainer.innerHTML = `
          <div class="flex items-center gap-2 text-sm text-orange-600 font-bold">
            <i class="fas fa-hands-praying"></i> Local Greeting: <span class="text-slate-900 font-extrabold text-base">${phrasebook.greeting}</span>
          </div>
        `;
      }

      if (listContainer) {
        listContainer.innerHTML = '';
        phrasebook.phrases.forEach(phrase => {
          const item = document.createElement('div');
          item.className = 'p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 hover:bg-orange-50/50 hover:border-orange-200 transition-colors flex flex-col justify-between';

          item.innerHTML = `
            <div class="flex items-start justify-between gap-2 mb-1.5">
              <span class="text-xs font-semibold text-slate-800">${phrase.en}</span>
              <button onclick="YatraApp.playPhraseAudio('${phrase.native.replace(/'/g, "\\'")}', '${langCode}', this)" 
                class="w-7 h-7 rounded-full bg-white hover:bg-orange-500 hover:text-white text-slate-600 border border-slate-200 flex items-center justify-center text-xs transition-colors shrink-0 cursor-pointer" 
                title="Listen Pronunciation via Python gTTS">
                <i class="fas fa-volume-high"></i>
              </button>
            </div>

            <div class="text-base font-bold text-orange-600 mb-0.5">
              ${phrase.native}
            </div>

            <div class="text-[11px] font-mono text-slate-500 mb-1">
              "${phrase.roman}"
            </div>

            <div class="text-[10px] text-teal-800 font-medium">
              💡 ${phrase.tip}
            </div>
          `;
          listContainer.appendChild(item);
        });
      }
    } catch (err) {
      console.error(err);
    }
  },

  // -------------------------------------------------------------
  // Audio Playback (Python gTTS Streaming with Browser Fallback)
  // -------------------------------------------------------------
  playPhraseAudio(text, langCode, btnElement) {
    if (btnElement) btnElement.classList.add('audio-playing', 'text-orange-600');

    // Attempt streaming audio from Python backend gTTS
    const audioUrl = `/api/tts/audio?text=${encodeURIComponent(text)}&lang=${encodeURIComponent(langCode)}`;
    const audio = new Audio(audioUrl);

    audio.play().then(() => {
      this.showToast(`Playing Python gTTS pronunciation: "${text}"`, 'info');
      audio.onended = () => {
        if (btnElement) btnElement.classList.remove('audio-playing', 'text-orange-600');
      };
    }).catch(err => {
      // Fallback to Web Speech Synthesis API if offline or audio fails
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.85;
        const langMap = { 'hi': 'hi-IN', 'ta': 'ta-IN', 'bn': 'bn-IN', 'mr': 'mr-IN', 'gu': 'gu-IN' };
        utterance.lang = langMap[langCode] || 'hi-IN';
        utterance.onend = () => {
          if (btnElement) btnElement.classList.remove('audio-playing', 'text-orange-600');
        };
        window.speechSynthesis.speak(utterance);
        this.showToast(`Pronouncing (Web Speech): "${text}"`, 'info');
      } else {
        if (btnElement) btnElement.classList.remove('audio-playing', 'text-orange-600');
        this.showToast('Audio playback not supported in your browser.', 'error');
      }
    });
  },

  // -------------------------------------------------------------
  // Student Buddy Pools (Python Backend Endpoints)
  // -------------------------------------------------------------
  bindBuddyPools() {
    const filterButtons = document.querySelectorAll('.pool-filter-btn');
    filterButtons.forEach(btn => {
      btn.addEventListener('click', async (e) => {
        filterButtons.forEach(b => {
          b.classList.remove('bg-orange-600', 'text-white');
          b.classList.add('bg-white', 'text-slate-700', 'border', 'border-slate-200');
        });
        e.currentTarget.classList.add('bg-orange-600', 'text-white');
        e.currentTarget.classList.remove('bg-white', 'text-slate-700', 'border', 'border-slate-200');

        const filter = e.currentTarget.dataset.filter;
        await this.fetchAndRenderBuddyPools(filter);
      });
    });

    const createPoolForm = document.getElementById('createPoolForm');
    if (createPoolForm) {
      createPoolForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await this.handleCreatePoolSubmit();
      });
    }
  },

  async fetchAndRenderBuddyPools(category = 'all') {
    try {
      const response = await fetch(`/api/buddy-pools?category=${encodeURIComponent(category)}`);
      const data = await response.json();
      if (!data.success) return;

      const container = document.getElementById('buddyPoolsList');
      if (!container) return;
      container.innerHTML = '';

      if (data.pools.length === 0) {
        container.innerHTML = `
          <div class="col-span-full py-12 text-center text-slate-500">
            <i class="fas fa-users-slash text-4xl text-slate-300 mb-3 block"></i>
            <p class="font-medium text-base">No active pools found in this category.</p>
            <p class="text-xs text-slate-400 mt-1">Be the first student to create a pool for your university!</p>
          </div>
        `;
        return;
      }

      data.pools.forEach(pool => {
        const card = document.createElement('div');
        card.className = 'bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm hover:shadow-md transition-all flex flex-col justify-between';

        const isGirlsOnly = pool.type.toLowerCase().includes('girls');
        const badgeColor = isGirlsOnly ? 'bg-pink-100 text-pink-700 border-pink-200' : 'bg-orange-100 text-orange-800 border-orange-200';

        card.innerHTML = `
          <div>
            <div class="flex items-start justify-between gap-3 mb-3">
              <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${badgeColor}">
                <i class="fas ${isGirlsOnly ? 'fa-shield-halved' : 'fa-users'}"></i> ${pool.type}
              </span>
              <div class="text-right">
                <span class="text-xs font-bold ${pool.seats_left > 0 ? 'text-emerald-600' : 'text-red-500'}">
                  ${pool.seats_left > 0 ? `${pool.seats_left} of ${pool.seats_total} Seats Left` : 'Pool Full'}
                </span>
              </div>
            </div>

            <h4 class="text-lg font-bold text-slate-900 mb-1 font-heading">${pool.destination}</h4>
            
            <div class="flex items-center gap-2 text-xs text-slate-500 mb-3">
              <span><i class="far fa-calendar-alt text-orange-500 mr-1"></i>${pool.date_range}</span>
              <span>•</span>
              <span><i class="fas fa-venus-mars text-teal-600 mr-1"></i>${pool.gender_pref}</span>
            </div>

            <p class="text-xs text-slate-600 mb-4 line-clamp-3 leading-relaxed">${pool.description}</p>
          </div>

          <div class="pt-4 border-t border-slate-100 mt-2">
            <div class="flex items-center justify-between mb-3 text-xs">
              <div class="flex items-center gap-2">
                <div class="w-8 h-8 rounded-full bg-slate-900 text-white font-bold flex items-center justify-center text-xs">
                  ${pool.creator_name.charAt(0)}
                </div>
                <div>
                  <p class="font-bold text-slate-800 flex items-center gap-1">
                    ${pool.creator_name}
                    ${pool.verified ? '<i class="fas fa-check-circle text-teal-500 text-[11px]" title="Verified Student ID"></i>' : ''}
                  </p>
                  <p class="text-[11px] text-slate-500">${pool.college}</p>
                </div>
              </div>
            </div>

            <div class="bg-slate-50 p-2.5 rounded-xl mb-3 text-xs flex items-center justify-between">
              <span class="text-slate-600 font-medium">Est. Split Share:</span>
              <span class="font-bold text-slate-900">${pool.cost_estimate}</span>
            </div>

            <button onclick="YatraApp.joinBuddyPool('${pool.id}')" 
              class="w-full py-2.5 px-4 rounded-xl font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                pool.seats_left > 0 
                  ? 'bg-slate-900 hover:bg-orange-600 text-white shadow-sm' 
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }" ${pool.seats_left === 0 ? 'disabled' : ''}>
              <i class="fas fa-user-plus"></i> ${pool.seats_left > 0 ? 'Request to Join Pool' : 'Pool Full'}
            </button>
          </div>
        `;

        container.appendChild(card);
      });
    } catch (err) {
      console.error(err);
    }
  },

  async handleCreatePoolSubmit() {
    const name = document.getElementById('poolCreatorName')?.value.trim();
    const college = document.getElementById('poolCollege')?.value.trim();
    const destination = document.getElementById('poolDestination')?.value.trim();
    const dateRange = document.getElementById('poolDates')?.value.trim();
    const poolType = document.getElementById('poolType')?.value || 'College Squad';
    const seatsTotal = parseInt(document.getElementById('poolSeats')?.value || '4', 10);
    const costEstimate = document.getElementById('poolCost')?.value.trim() || 'Split equally';
    const genderPref = document.getElementById('poolGenderPref')?.value || 'Open to All Students';
    const description = document.getElementById('poolDesc')?.value.trim();

    try {
      const response = await fetch('/api/buddy-pools', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          creator_name: name,
          college: college,
          destination: destination,
          date_range: dateRange,
          pool_type: poolType,
          seats_total: seatsTotal,
          cost_estimate: costEstimate,
          gender_pref: genderPref,
          description: description
        })
      });

      const data = await response.json();
      if (!data.success) throw new Error(data.error || 'Failed to create pool');

      document.getElementById('createPoolModal')?.classList.add('hidden');
      document.getElementById('createPoolForm')?.reset();
      this.showToast('🎉 Travel pool created successfully via Python backend!', 'success');
      await this.fetchAndRenderBuddyPools('all');

    } catch (err) {
      console.error(err);
      this.showToast('Failed to create pool. Check required fields.', 'error');
    }
  },

  async joinBuddyPool(poolId) {
    try {
      const response = await fetch(`/api/buddy-pools/${poolId}/join`, {
        method: 'POST'
      });
      const data = await response.json();
      if (data.success) {
        this.showToast(data.message, 'success');
        await this.fetchAndRenderBuddyPools('all');
      } else {
        this.showToast(data.message || 'Unable to join pool.', 'error');
      }
    } catch (err) {
      console.error(err);
      this.showToast('Network error joining pool.', 'error');
    }
  },

  // -------------------------------------------------------------
  // Budget Tracker (Python Backend Calculations)
  // -------------------------------------------------------------
  bindBudgetCalculator() {
    const inputs = ['totalBudgetInput', 'budgetTravelers', 'budgetDays', 'budgetStayType'];
    inputs.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('input', () => this.updateBudgetBreakdown());
        el.addEventListener('change', () => this.updateBudgetBreakdown());
      }
    });
  },

  async updateBudgetBreakdown() {
    const totalBudget = parseFloat(document.getElementById('totalBudgetInput')?.value || '6000');
    const travelers = parseInt(document.getElementById('budgetTravelers')?.value || '3', 10);
    const days = parseInt(document.getElementById('budgetDays')?.value || '4', 10);
    const stayType = document.getElementById('budgetStayType')?.value || 'hostel';

    const travelerVal = document.getElementById('budgetTravelerVal');
    if (travelerVal) travelerVal.textContent = `${travelers} ${travelers === 1 ? 'Student' : 'Students'}`;

    const daysVal = document.getElementById('budgetDaysVal');
    if (daysVal) daysVal.textContent = `${days} ${days === 1 ? 'Day' : 'Days'}`;

    try {
      const response = await fetch('/api/budget/calculate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          total_budget: totalBudget,
          travelers: travelers,
          days: days,
          stay_type: stayType
        })
      });

      const res = await response.json();
      if (!res.success) return;

      const b = res.budget;

      const perStudentEl = document.getElementById('perStudentShare');
      if (perStudentEl) perStudentEl.textContent = `₹${b.per_student_share.toLocaleString('en-IN')}`;

      const perDayEl = document.getElementById('perStudentDaily');
      if (perDayEl) perDayEl.textContent = `₹${b.per_student_daily.toLocaleString('en-IN')}/day`;

      const stayEl = document.getElementById('budgetStayCost');
      if (stayEl) stayEl.textContent = `₹${b.breakdown.stays.toLocaleString('en-IN')}`;

      const transitEl = document.getElementById('budgetTransitCost');
      if (transitEl) transitEl.textContent = `₹${b.breakdown.transit.toLocaleString('en-IN')}`;

      const foodEl = document.getElementById('budgetFoodCost');
      if (foodEl) foodEl.textContent = `₹${b.breakdown.food.toLocaleString('en-IN')}`;

      const activityEl = document.getElementById('budgetActivityCost');
      if (activityEl) activityEl.textContent = `₹${b.breakdown.activities.toLocaleString('en-IN')}`;

      const emergencyEl = document.getElementById('budgetEmergencyCost');
      if (emergencyEl) emergencyEl.textContent = `₹${b.breakdown.emergency_buffer.toLocaleString('en-IN')}`;

      this.renderBudgetChart(b.chart_data);

    } catch (err) {
      console.error('Budget calculation error:', err);
    }
  },

  renderBudgetChart(chartData) {
    const canvas = document.getElementById('budgetDonutChart');
    if (!canvas || typeof Chart === 'undefined') return;

    const ctx = canvas.getContext('2d');
    const data = {
      labels: chartData.labels,
      datasets: [{
        data: chartData.values,
        backgroundColor: chartData.colors,
        borderWidth: 3,
        borderColor: '#FFFFFF',
        hoverOffset: 6
      }]
    };

    if (this.chartInstance) {
      this.chartInstance.data = data;
      this.chartInstance.update();
    } else {
      this.chartInstance = new Chart(ctx, {
        type: 'doughnut',
        data: data,
        options: {
          responsive: true,
          maintainAspectRatio: false,
          cutout: '72%',
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: '#0B192C',
              titleFont: { family: 'Outfit', size: 13 },
              bodyFont: { family: 'Plus Jakarta Sans', size: 12 },
              padding: 10,
              cornerRadius: 8,
              callbacks: {
                label: function(ctx) {
                  return ` ${ctx.label}: ₹${ctx.raw.toLocaleString('en-IN')}`;
                }
              }
            }
          }
        }
      });
    }
  },

  // -------------------------------------------------------------
  // Chatbot (Python NLP Backend)
  // -------------------------------------------------------------
  bindChatbot() {
    const toggleBtn = document.getElementById('chatToggleBtn');
    const closeBtn = document.getElementById('chatCloseBtn');
    const sendBtn = document.getElementById('chatSendBtn');
    const inputField = document.getElementById('chatInput');

    if (toggleBtn) toggleBtn.addEventListener('click', () => this.toggleChat());
    if (closeBtn) closeBtn.addEventListener('click', () => this.toggleChat(false));
    if (sendBtn) sendBtn.addEventListener('click', () => this.handleChatSend());
    if (inputField) {
      inputField.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          this.handleChatSend();
        }
      });
    }

    document.querySelectorAll('.chat-chip').forEach(chip => {
      chip.addEventListener('click', (e) => {
        const query = e.currentTarget.textContent.trim();
        this.sendChatQuery(query);
      });
    });
  },

  toggleChat(forceState) {
    const container = document.getElementById('chatWidgetContainer');
    const badge = document.getElementById('chatUnreadBadge');
    if (!container) return;

    const isHidden = container.classList.contains('hidden');
    const nextState = typeof forceState === 'boolean' ? !forceState : !isHidden;

    if (nextState) {
      container.classList.add('hidden');
    } else {
      container.classList.remove('hidden');
      if (badge) badge.classList.add('hidden');
      setTimeout(() => document.getElementById('chatInput')?.focus(), 150);
    }
  },

  sendChatQuery(text) {
    this.toggleChat(true);
    const input = document.getElementById('chatInput');
    if (input) input.value = text;
    this.handleChatSend();
  },

  async handleChatSend() {
    const input = document.getElementById('chatInput');
    if (!input) return;
    const message = input.value.trim();
    if (!message) return;

    this.appendChatMessage(message, 'user');
    input.value = '';

    this.showChatTyping();

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: message })
      });
      const data = await response.json();
      this.hideChatTyping();

      if (data.success) {
        this.appendChatMessage(data.reply.response, 'bot');
      } else {
        this.appendChatMessage('Sorry, I encountered an error answering that.', 'bot');
      }
    } catch (err) {
      this.hideChatTyping();
      this.appendChatMessage('Connection error reaching Yatra AI server.', 'bot');
    }
  },

  appendChatMessage(content, sender) {
    const history = document.getElementById('chatHistory');
    if (!history) return;

    const msgWrapper = document.createElement('div');
    msgWrapper.className = `flex ${sender === 'user' ? 'justify-end' : 'justify-start'} mb-3`;

    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    let formattedText = content
      .replace(/\n\n/g, '<br><br>')
      .replace(/\n/g, '<br>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/•/g, '&bull;');

    if (sender === 'user') {
      msgWrapper.innerHTML = `
        <div class="max-w-[85%] bg-orange-600 text-white p-3 rounded-2xl rounded-tr-xs text-xs shadow-sm">
          <p>${formattedText}</p>
          <div class="text-[10px] text-orange-200 text-right mt-1">${timeStr}</div>
        </div>
      `;
    } else {
      msgWrapper.innerHTML = `
        <div class="flex items-start gap-2 max-w-[90%]">
          <div class="w-7 h-7 rounded-full bg-slate-900 text-orange-400 flex items-center justify-center text-xs shrink-0 mt-0.5 shadow">
            <i class="fas fa-robot"></i>
          </div>
          <div class="bg-white text-slate-800 p-3 rounded-2xl rounded-tl-xs text-xs border border-slate-200/80 shadow-sm">
            <div class="leading-relaxed">${formattedText}</div>
            <div class="text-[10px] text-slate-400 mt-1.5 flex items-center justify-between">
              <span>Yatra AI Bot</span>
              <span>${timeStr}</span>
            </div>
          </div>
        </div>
      `;
    }

    history.appendChild(msgWrapper);
    history.scrollTop = history.scrollHeight;
  },

  showChatTyping() {
    const history = document.getElementById('chatHistory');
    if (!history) return;

    const indicator = document.createElement('div');
    indicator.id = 'chatTypingIndicator';
    indicator.className = 'flex items-center gap-2 mb-3';
    indicator.innerHTML = `
      <div class="w-7 h-7 rounded-full bg-slate-900 text-orange-400 flex items-center justify-center text-xs shrink-0">
        <i class="fas fa-robot"></i>
      </div>
      <div class="bg-white border border-slate-200/80 p-2.5 rounded-2xl rounded-tl-xs text-xs shadow-sm flex items-center gap-1">
        <span class="w-1.5 h-1.5 bg-orange-500 rounded-full animate-bounce"></span>
        <span class="w-1.5 h-1.5 bg-orange-500 rounded-full animate-bounce [animation-delay:0.2s]"></span>
        <span class="w-1.5 h-1.5 bg-orange-500 rounded-full animate-bounce [animation-delay:0.4s]"></span>
      </div>
    `;
    history.appendChild(indicator);
    history.scrollTop = history.scrollHeight;
  },

  hideChatTyping() {
    document.getElementById('chatTypingIndicator')?.remove();
  },

  // -------------------------------------------------------------
  // EduPass Student Verification (Python Endpoint)
  // -------------------------------------------------------------
  bindEduPassModal() {
    const openBtn = document.getElementById('openEduPassBtn');
    const openBtnMobile = document.getElementById('openEduPassBtnMobile');
    const modal = document.getElementById('eduPassModal');
    const closeBtn = document.getElementById('closeEduPassBtn');
    const form = document.getElementById('eduPassForm');

    const show = () => modal?.classList.remove('hidden');
    if (openBtn) openBtn.addEventListener('click', show);
    if (openBtnMobile) openBtnMobile.addEventListener('click', show);
    if (closeBtn) closeBtn.addEventListener('click', () => modal?.classList.add('hidden'));

    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = document.getElementById('eduName')?.value.trim();
        const college = document.getElementById('eduCollege')?.value.trim();
        const idNum = document.getElementById('eduIdNumber')?.value.trim();

        try {
          const response = await fetch('/api/edupass/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              student_name: name,
              college_name: college,
              student_id: idNum
            })
          });

          const data = await response.json();
          if (data.success) {
            this.isStudentVerified = true;
            const navBtnText = document.getElementById('eduPassBtnText');
            if (navBtnText) {
              navBtnText.innerHTML = `
                <span class="flex items-center gap-1.5">
                  <i class="fas fa-badge-check text-teal-400"></i> ${name.split(' ')[0]} (EduPass)
                </span>
              `;
            }
            modal?.classList.add('hidden');
            this.showToast(data.message, 'success');
          }
        } catch (err) {
          console.error(err);
          this.showToast('Verification server error.', 'error');
        }
      });
    }
  }
};

document.addEventListener('DOMContentLoaded', () => {
  YatraApp.init();
});

window.YatraApp = YatraApp;
