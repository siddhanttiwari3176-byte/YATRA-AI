"""
YATRA AI - Planner Service
Handles AI Itinerary Synthesis, Student Concessions, and Low-Carbon Route Waypoints.
"""

from typing import Dict, Any, List

DESTINATIONS_DATA = {
    "himachal": {
        "key": "himachal",
        "name": "Kasol & Parvati Valley, Himachal Pradesh",
        "tagline": "Alpine serenity, riverside cafes & student trekking havens",
        "state": "Himachal Pradesh",
        "vibe": "Mountain & Trekking",
        "coords": [32.0100, 77.3150],
        "base_cost_per_day": 1200,
        "carbon_per_day": "12 kg CO₂e (Eco-Friendly)",
        "highlights": ["Chalal riverside trail", "Manikaran hot springs", "Kheerganga natural sulfur pool", "Tosh village cafes"],
        "student_tips": "HRTC ordinary buses from Bhuntar save 70% compared to private taxis. Carry your college ID for discounts at registered youth hostels.",
        "days": [
            {
                "day": 1,
                "title": "Riverside Arrival & Chalal Forest Trail",
                "coords": [32.0100, 77.3150],
                "morning": {
                    "time": "09:00 AM - 12:30 PM",
                    "activity": "Arrival at Bhuntar, take local HRTC bus to Kasol. Check into riverside student backpacker hostel.",
                    "cost": "₹180 (Bus) + ₹450 (Dorm bed)",
                    "type": "Transit & Stay",
                    "student_perk": "20% off with verified EduPass at Nomads Hostel"
                },
                "afternoon": {
                    "time": "01:30 PM - 05:00 PM",
                    "activity": "Hike through pine forests to Chalal village. Try authentic trout and siddu at local Himachali family-run kitchen.",
                    "cost": "₹220 (Meal)",
                    "type": "Cultural Cuisine",
                    "student_perk": "Free herbal tea with local community passport"
                },
                "evening": {
                    "time": "06:30 PM - 09:30 PM",
                    "activity": "Acoustic jam session and stargazing by the Parvati riverbank. Plan group trek for next morning.",
                    "cost": "Free",
                    "type": "Social & Leisure",
                    "student_perk": "Join shared bonfire circle"
                }
            },
            {
                "day": 2,
                "title": "Manikaran Sahib & Trek to Tosh Village",
                "coords": [32.0170, 77.4500],
                "morning": {
                    "time": "08:30 AM - 12:00 PM",
                    "activity": "Shared electric cab to Manikaran Sahib Gurudwara. Dip in therapeutic natural hot springs & Langar meal.",
                    "cost": "₹60 (Shared e-cab)",
                    "type": "Spiritual & Heritage",
                    "student_perk": "Community Langar meal (Seva / Free)"
                },
                "afternoon": {
                    "time": "01:00 PM - 05:30 PM",
                    "activity": "Trek up to scenic Tosh village at 2,400m altitude. Wooden Himachali architecture and apple orchards.",
                    "cost": "₹150 (Shared taxi from Barshaini)",
                    "type": "Adventure Hike",
                    "student_perk": "Student group gear rental discount (30%)"
                },
                "evening": {
                    "time": "06:30 PM - 09:30 PM",
                    "activity": "Sunset panoramic view of Shrikhand Mahadev peak. Local wood-fired pizza and mountain music.",
                    "cost": "₹250 (Dinner)",
                    "type": "Leisure",
                    "student_perk": "Discounted board games & hot cocoa"
                }
            },
            {
                "day": 3,
                "title": "Kheerganga Trail or Malana Cultural Walk",
                "coords": [31.9930, 77.5110],
                "morning": {
                    "time": "07:30 AM - 01:00 PM",
                    "activity": "Ascend the misty waterfalls of Rudranag trail towards Kheerganga. Guided student group safety pod.",
                    "cost": "₹350 (Guide split)",
                    "type": "Trekking",
                    "student_perk": "Free eco-waste bag provided (Clean Himalayas badge)"
                },
                "afternoon": {
                    "time": "02:00 PM - 05:30 PM",
                    "activity": "Relax in top hot springs with 360-degree snow-capped Himalayas vista. Packed healthy student lunch.",
                    "cost": "₹180",
                    "type": "Wellness & Nature",
                    "student_perk": "Eco-tourism discount on tent pitch"
                },
                "evening": {
                    "time": "06:30 PM - 09:00 PM",
                    "activity": "Campfire astronomy and descend back / camp overnight under clear Milky Way sky.",
                    "cost": "₹400 (Shared tent)",
                    "type": "Night Adventure",
                    "student_perk": "Free sleeping bag upgrade for student groups"
                }
            }
        ]
    },
    "hampi": {
        "key": "hampi",
        "name": "Hampi & Anegundi, Karnataka",
        "tagline": "UNESCO Vijayanagara ruins, boulder trails & tungsten sunsets",
        "state": "Karnataka",
        "vibe": "Heritage & History",
        "coords": [15.3350, 76.4600],
        "base_cost_per_day": 950,
        "carbon_per_day": "9 kg CO₂e (Low-impact cycle transit)",
        "highlights": ["Virupaksha Temple complex", "Matanga Hill sunrise", "Coracle boat ride on Tungabhadra", "Anegundi rural artisans"],
        "student_tips": "Rent a bicycle for ₹100/day to explore ancient complexes. Carry your college ID for free or ₹25 entry tickets at ASI ticket counters.",
        "days": [
            {
                "day": 1,
                "title": "Sacred Ruins & Matanga Hill Sunset",
                "coords": [15.3350, 76.4600],
                "morning": {
                    "time": "06:00 AM - 11:30 AM",
                    "activity": "Climb Matanga Hill for iconic golden hour sunrise over boulder kingdom. Visit 7th-century Virupaksha Temple.",
                    "cost": "₹50 (ASI pass with Student ID)",
                    "type": "Heritage & Trek",
                    "student_perk": "50% discount on ASI monument passes"
                },
                "afternoon": {
                    "time": "01:00 PM - 04:30 PM",
                    "activity": "Cycle through the Royal Enclosure, Hazara Rama temple bas-reliefs, and Lotus Mahal.",
                    "cost": "₹100 (Bicycle rental for full day)",
                    "type": "Eco Exploration",
                    "student_perk": "Bicycle shared coupon via YATRA app"
                },
                "evening": {
                    "time": "05:30 PM - 08:30 PM",
                    "activity": "Traditional South Indian Thali on banana leaf at Mango Tree cafe. Chill at Tungabhadra river steps.",
                    "cost": "₹160 (Unlimited Thali)",
                    "type": "Culinary Heritage",
                    "student_perk": "Student loyalty beverage"
                }
            },
            {
                "day": 2,
                "title": "Vittala Musical Pillars & Coracle Crossings",
                "coords": [15.3420, 76.4750],
                "morning": {
                    "time": "08:30 AM - 12:30 PM",
                    "activity": "Audio-guided exploration of the iconic Stone Chariot and musical pillars at Vijaya Vittala Complex.",
                    "cost": "₹40 (Ticket) + ₹80 (Audio Guide)",
                    "type": "UNESCO Heritage",
                    "student_perk": "Free audio guide QR on YATRA AI"
                },
                "afternoon": {
                    "time": "01:30 PM - 05:00 PM",
                    "activity": "Cross Tungabhadra river via traditional round woven Coracle boat. Explore Hippie Island and Sanapur lake.",
                    "cost": "₹70 (Coracle ride shared)",
                    "type": "Local Transit & Adventure",
                    "student_perk": "Group coracle discount"
                },
                "evening": {
                    "time": "06:00 PM - 09:00 PM",
                    "activity": "Sunset bouldering with local certified climbers. Folk music showcase at local homestay.",
                    "cost": "₹200",
                    "type": "Culture & Sport",
                    "student_perk": "Free crash-pad sharing for college squads"
                }
            },
            {
                "day": 3,
                "title": "Anegundi Ancient Heritage & Rural Artisans",
                "coords": [15.3520, 76.4950],
                "morning": {
                    "time": "08:00 AM - 12:00 PM",
                    "activity": "Visit the mythological Kishkindha (Anjaneya Hill) and historic water conservation channels of Vijayanagara.",
                    "cost": "Free",
                    "type": "Mythology & Nature",
                    "student_perk": "Student historical map handout"
                },
                "afternoon": {
                    "time": "01:00 PM - 04:30 PM",
                    "activity": "Banana fiber craft workshop at Anegundi Women's Artisan Guild. Learn indigenous weaving technique.",
                    "cost": "₹150 (Hands-on workshop fee)",
                    "type": "Vocal for Local",
                    "student_perk": "Take home your handwoven souvenir"
                },
                "evening": {
                    "time": "05:30 PM - 08:30 PM",
                    "activity": "Farewell rooftop dinner overlooking paddy fields and ancient stone towers. Board night train from Hospet.",
                    "cost": "₹200 (Dinner)",
                    "type": "Departure",
                    "student_perk": "Student shared shuttle to Hospet Jn"
                }
            }
        ]
    },
    "varanasi": {
        "key": "varanasi",
        "name": "Varanasi (Kashi), Uttar Pradesh",
        "tagline": "Eternal ghats, spiritual dawn, silk weavers & legendary street food",
        "state": "Uttar Pradesh",
        "vibe": "Spiritual Trails",
        "coords": [25.3176, 82.9739],
        "base_cost_per_day": 800,
        "carbon_per_day": "8 kg CO₂e (Walking & Electric boat)",
        "highlights": ["Subah-e-Banaras at Assi Ghat", "Ganga Aarti at Dashashwamedh", "Kachori Gali & Blue Lassi food walk", "Sarai Mohana silk weaving village"],
        "student_tips": "Join the Subah-e-Banaras morning music program at Assi Ghat for free. Shared e-rickshaws anywhere along Godowlia cost only ₹15-20.",
        "days": [
            {
                "day": 1,
                "title": "Subah-e-Banaras, Sacred Ghats & Evening Aarti",
                "coords": [25.3176, 82.9739],
                "morning": {
                    "time": "05:30 AM - 10:00 AM",
                    "activity": "Sunrise rowing boat from Assi Ghat to Manikarnika. Witness morning ragas, yoga on the ghat, and historic architecture.",
                    "cost": "₹120 (Shared student boat seat)",
                    "type": "Heritage & River",
                    "student_perk": "Shared e-boat student pool via YATRA"
                },
                "afternoon": {
                    "time": "11:30 AM - 04:00 PM",
                    "activity": "Street food pilgrimage: Ram Bhandar kachori sabzi, malyo (winter foam dessert), and world-famous Pahalwan lassi.",
                    "cost": "₹160 (Full food trail)",
                    "type": "Culinary Heritage",
                    "student_perk": "Free food trail audio commentary"
                },
                "evening": {
                    "time": "06:00 PM - 09:30 PM",
                    "activity": "Watch the world-famous Grand Maha Aarti at Dashashwamedh Ghat from steps. Night walk through ancient alleyways.",
                    "cost": "Free",
                    "type": "Spiritual Ceremony",
                    "student_perk": "Priority student photography deck"
                }
            },
            {
                "day": 2,
                "title": "Sarnath Buddhist Trail & Banarasi Silk Weavers",
                "coords": [25.3811, 83.0214],
                "morning": {
                    "time": "08:30 AM - 01:00 PM",
                    "activity": "E-rickshaw to Sarnath where Buddha delivered his first sermon. Dhamek Stupa and Sarnath ASI Archeological Museum.",
                    "cost": "₹25 (Student Museum pass) + ₹40 (E-rickshaw)",
                    "type": "UNESCO Buddhist Trail",
                    "student_perk": "Zero entry fee for students with ID on select days"
                },
                "afternoon": {
                    "time": "02:00 PM - 05:30 PM",
                    "activity": "Visit Sarai Mohana village. Witness Master Weaver families crafting authentic Zari Banarasi sarees on handlooms.",
                    "cost": "Free / Community tip",
                    "type": "Vocal for Local",
                    "student_perk": "Direct artisan pricing on fabric souvenirs"
                },
                "evening": {
                    "time": "06:30 PM - 09:00 PM",
                    "activity": "Rooftop classical sitar and tabla performance at Assi Ghat cultural center with masala chai.",
                    "cost": "₹150",
                    "type": "Performing Arts",
                    "student_perk": "Student entry concession"
                }
            }
        ]
    },
    "rishikesh": {
        "key": "rishikesh",
        "name": "Rishikesh & Shivpuri, Uttarakhand",
        "tagline": "Yoga capital of the world, white water rapids & Himalayan cliff cafes",
        "state": "Uttarakhand",
        "vibe": "Adventure Trek",
        "coords": [30.0869, 78.2676],
        "base_cost_per_day": 1100,
        "carbon_per_day": "11 kg CO₂e (Eco-friendly shared jeeps)",
        "highlights": ["16km White Water Rafting", "Beatles Ashram graffiti walk", "Triveni Ghat Evening Aarti", "Neer Garh waterfall hike"],
        "student_tips": "Book rafting directly with certified Uttarakhand Tourism (UTDB) operators in groups of 8 to get flat student rates of ₹650 per person.",
        "days": [
            {
                "day": 1,
                "title": "White Water Rafting & Cliff Jumping",
                "coords": [30.0869, 78.2676],
                "morning": {
                    "time": "08:30 AM - 01:30 PM",
                    "activity": "16 km thrilling Grade III/IV white water rafting from Shivpuri to NIM Beach with cliff jumping and body surfing.",
                    "cost": "₹650 (Group student rate)",
                    "type": "Adventure Sports",
                    "student_perk": "Free GoPro action video split"
                },
                "afternoon": {
                    "time": "02:30 PM - 05:30 PM",
                    "activity": "Hike to Neer Garh multi-tier waterfall. Cool dip in natural stone pools followed by Maggi and chai.",
                    "cost": "₹30 (Entry fee)",
                    "type": "Eco Trek",
                    "student_perk": "Free entry for students with college ID"
                },
                "evening": {
                    "time": "06:30 PM - 09:00 PM",
                    "activity": "Spiritual Ganga Aarti at Triveni Ghat with oil lamps floating on the holy river. Chanting and live bell chimes.",
                    "cost": "Free",
                    "type": "Spiritual & Community",
                    "student_perk": "Open seating"
                }
            },
            {
                "day": 2,
                "title": "Beatles Ashram & Tapovan Cafe Culture",
                "coords": [30.1158, 78.3180],
                "morning": {
                    "time": "09:00 AM - 01:00 PM",
                    "activity": "Explore the Beatles Ashram (Chaurasi Kutia) in Rajaji Tiger Reserve. Marvel at psychedelic murals and meditation domes.",
                    "cost": "₹75 (Student concession pass)",
                    "type": "Heritage & Art",
                    "student_perk": "50% discount on forest entry ticket"
                },
                "afternoon": {
                    "time": "02:00 PM - 05:30 PM",
                    "activity": "Cafe hopping in Tapovan: Try vegan thali, woodfired pizza, and smoothie bowls overlooking Lakshman Jhula.",
                    "cost": "₹250",
                    "type": "Student Hangout",
                    "student_perk": "15% off food bill with EduPass"
                },
                "evening": {
                    "time": "06:30 PM - 09:30 PM",
                    "activity": "Riverside acoustic guitar circle and beach camping setup on pristine white sand Ganga bank.",
                    "cost": "₹450 (Riverside tent stay)",
                    "type": "Camping",
                    "student_perk": "Shared campfire wood & stargazing telescope"
                }
            }
        ]
    },
    "meghalaya": {
        "key": "meghalaya",
        "name": "Shillong, Cherrapunji & Mawlynnong, Meghalaya",
        "tagline": "Living root bridges, crystal rivers, misty waterfalls & matrilineal culture",
        "state": "Meghalaya",
        "vibe": "Eco-Tourism",
        "coords": [25.5788, 91.8933],
        "base_cost_per_day": 1350,
        "carbon_per_day": "10 kg CO₂e (Carbon-neutral community homestays)",
        "highlights": ["Double Decker Living Root Bridge", "Umngot River transparent boats at Dawki", "Mawlynnong Asia's Cleanest Village", "Nohkalikai Waterfall"],
        "student_tips": "Shared sumo cabs from Police Bazar in Shillong to Cherrapunji cost only ₹120. Stay in community-run Khasi homestays.",
        "days": [
            {
                "day": 1,
                "title": "Misty Waterfalls & Khasi Heritage in Sohra",
                "coords": [25.2744, 91.7323],
                "morning": {
                    "time": "08:00 AM - 12:30 PM",
                    "activity": "Shared cab to Sohra (Cherrapunji). Gaze at India's tallest plunge waterfall Nohkalikai & explore Mawsmai limestone cave.",
                    "cost": "₹120 (Transit) + ₹50 (Cave pass)",
                    "type": "Geological Wonder",
                    "student_perk": "Eco-Tourism student card concession"
                },
                "afternoon": {
                    "time": "01:30 PM - 05:00 PM",
                    "activity": "Hike down the 3,000 stone stairs to Nongriat to marvel at the 250-year-old Double Decker Living Root Bridge.",
                    "cost": "₹100 (Community maintenance fee)",
                    "type": "Indigenous Engineering",
                    "student_perk": "Free bamboo trekking pole rental"
                },
                "evening": {
                    "time": "06:00 PM - 09:00 PM",
                    "activity": "Overnight in Nongriat village homestay. Enjoy warm Khasi home-cooked stew and listening to tribal folklore.",
                    "cost": "₹400 (Homestay bed & dinner)",
                    "type": "Community Homestay",
                    "student_perk": "Direct contribution to tribal self-help fund"
                }
            },
            {
                "day": 2,
                "title": "Dawki Crystal Waters & Cleanest Village Mawlynnong",
                "coords": [25.1880, 92.0234],
                "morning": {
                    "time": "08:00 AM - 12:30 PM",
                    "activity": "Head to Dawki border. Row on the unreal glass-like waters of Umngot River where boats appear to float in mid-air.",
                    "cost": "₹250 (Shared boat ride)",
                    "type": "Eco Water Trail",
                    "student_perk": "YATRA pooled student boat"
                },
                "afternoon": {
                    "time": "01:30 PM - 05:30 PM",
                    "activity": "Walk through Mawlynnong, recognized as Asia's Cleanest Village. Discover zero-waste bamboo dustbins and treehouses.",
                    "cost": "₹50",
                    "type": "Sustainability Model",
                    "student_perk": "Student environmental workshop certificate"
                },
                "evening": {
                    "time": "06:30 PM - 09:30 PM",
                    "activity": "Return to Shillong Police Bazar. Indie rock live performance at Dylan's Cafe with steamed pork/veg momos.",
                    "cost": "₹220",
                    "type": "Culture & Music",
                    "student_perk": "10% music gig discount for college students"
                }
            }
        ]
    },
    "gokarna": {
        "key": "gokarna",
        "name": "Gokarna & Honnavar, Karnataka",
        "tagline": "Pristine cliffside beach treks, Arabian sunset cafes & quiet temple lanes",
        "state": "Karnataka",
        "vibe": "Coastal & Relax",
        "coords": [14.5479, 74.3188],
        "base_cost_per_day": 900,
        "carbon_per_day": "7 kg CO₂e (Walking coastal trails)",
        "highlights": ["Five Beach Trek (Kudle, Om, Half Moon, Paradise)", "Honnavar mangrove boat safari", "Mahabaleshwar Temple", "Cliffside hammock cafes"],
        "student_tips": "Trek between beaches on foot rather than taking expensive autos. Om Beach to Paradise Beach is a stunning 2-hour coastal walk.",
        "days": [
            {
                "day": 1,
                "title": "The Legendary 5-Beach Cliff Trek",
                "coords": [14.5479, 74.3188],
                "morning": {
                    "time": "07:00 AM - 12:30 PM",
                    "activity": "Start from Gokarna Main Beach, traverse cliffs through Kudle Beach to the sacred Om-shaped coastline.",
                    "cost": "Free (Hiking trail)",
                    "type": "Coastal Trekking",
                    "student_perk": "Download offline GPS trail map on YATRA"
                },
                "afternoon": {
                    "time": "01:00 PM - 04:30 PM",
                    "activity": "Trek through rugged rocks to secluded Half Moon Beach and Paradise Beach. Swim in calm turquoise coves.",
                    "cost": "₹180 (Fresh coconut & shack lunch)",
                    "type": "Nature & Beach",
                    "student_perk": "Student group safety beacon sync"
                },
                "evening": {
                    "time": "05:30 PM - 09:00 PM",
                    "activity": "Sunset drum circle and fire spinning at Kudle Beach. Fresh woodfired seafood/falafel platter.",
                    "cost": "₹240 (Dinner)",
                    "type": "Bohemian Sunset",
                    "student_perk": "Free beach yoga mat rental"
                }
            },
            {
                "day": 2,
                "title": "Honnavar Mangrove Safari & Bioluminescence",
                "coords": [14.2810, 74.4439],
                "morning": {
                    "time": "08:30 AM - 01:00 PM",
                    "activity": "Shared local passenger train to Honnavar (₹20). Kayak or eco-boat through serene Sharavati river backwaters.",
                    "cost": "₹20 (Train) + ₹200 (Boat safari)",
                    "type": "Eco Waterway",
                    "student_perk": "Student group kayak discount (25%)"
                },
                "afternoon": {
                    "time": "02:00 PM - 05:30 PM",
                    "activity": "Explore 4th-century Mahabaleshwar Temple with Atmalinga shrine. Taste authentic Karavali curries.",
                    "cost": "₹120 (Traditional meal)",
                    "type": "Spiritual & Heritage",
                    "student_perk": "Free temple heritage walkthrough"
                },
                "evening": {
                    "time": "07:00 PM - 10:00 PM",
                    "activity": "Night walk along Nirvana beach to spot glowing blue marine bioluminescence in sea waves (seasonal).",
                    "cost": "Free",
                    "type": "Night Phenomenon",
                    "student_perk": "Night safety buddy tracker enabled"
                }
            }
        ]
    }
}


class PlannerService:
    @staticmethod
    def get_destinations_overview() -> List[Dict[str, Any]]:
        overview = []
        for key, data in DESTINATIONS_DATA.items():
            overview.append({
                "key": key,
                "name": data["name"],
                "tagline": data["tagline"],
                "state": data["state"],
                "vibe": data["vibe"],
                "coords": data["coords"],
                "base_cost_per_day": data["base_cost_per_day"],
                "highlights": data["highlights"]
            })
        return overview

    @staticmethod
    def generate_itinerary(
        destination: str = "himachal",
        duration: int = 3,
        budget_tier: str = "budget",
        vibe: str = "adventure",
        group_type: str = "solo"
    ) -> Dict[str, Any]:
        dest_key = destination.lower()
        # Find closest match or default
        if dest_key not in DESTINATIONS_DATA:
            for key in DESTINATIONS_DATA:
                if key in dest_key:
                    dest_key = key
                    break
            else:
                dest_key = "himachal"

        dest_data = DESTINATIONS_DATA[dest_key]
        duration = max(1, min(duration, len(dest_data["days"])))

        # Budget Multipliers
        tier_multiplier = 1.0
        tier_label = "Student Shoestring"
        if budget_tier == "backpacker":
            tier_multiplier = 1.35
            tier_label = "Backpacker Standard"
        elif budget_tier == "comfort":
            tier_multiplier = 1.85
            tier_label = "Comfort Explorer"

        # Group Discounts
        group_factor = 1.0
        group_savings_label = "Solo Traveler"
        if group_type == "duo":
            group_factor = 0.90
            group_savings_label = "10% shared room savings"
        elif group_type == "squad":
            group_factor = 0.78
            group_savings_label = "22% group cab & stay discount"

        total_cost_per_student = int(dest_data["base_cost_per_day"] * duration * tier_multiplier * group_factor)
        savings = int(total_cost_per_student * 0.28)

        # Slice days
        selected_days = dest_data["days"][:duration]
        waypoints = [d["coords"] for d in selected_days]

        return {
            "destination_key": dest_key,
            "destination_name": dest_data["name"],
            "tagline": dest_data["tagline"],
            "state": dest_data["state"],
            "vibe": dest_data["vibe"],
            "duration": duration,
            "tier_label": tier_label,
            "group_savings_label": group_savings_label,
            "estimated_cost_per_student": total_cost_per_student,
            "student_savings": savings,
            "carbon_score": dest_data["carbon_per_day"],
            "student_tips": dest_data["student_tips"],
            "days": selected_days,
            "waypoints": waypoints
        }
