"""
YATRA AI - Student Travel Pool & Buddy Service
Manages shared rides, trekking squads, and female-only safety pools.
"""

import time
import threading
from typing import List, Dict, Any, Optional

INITIAL_POOLS = [
    {
        "id": "pool-101",
        "creator_name": "Aryan Sharma",
        "college": "IIT Delhi (Batch '26)",
        "destination": "Kasol & Kheerganga Trek",
        "date_range": "Oct 12 - Oct 15",
        "type": "Trekking Squad",
        "seats_total": 5,
        "seats_left": 2,
        "cost_estimate": "₹850 / person for private tempo traveler from Majnu Ka Tilla",
        "gender_pref": "Open to All Students",
        "verified": True,
        "description": "Booked a clean 12-seater tempo from Delhi to Kasol. We are 3 computer science students, looking for 2 fellow students to split the travel cost and share a Kheerganga tent!"
    },
    {
        "id": "pool-102",
        "creator_name": "Ananya Iyer & Riya Sen",
        "college": "St. Xavier's Mumbai",
        "destination": "Gokarna Cliff & Beach Camping",
        "date_range": "Nov 02 - Nov 05",
        "type": "Girls-Only Safe Pool",
        "seats_total": 4,
        "seats_left": 2,
        "cost_estimate": "₹650 / person for shared beach cottage & cab",
        "gender_pref": "Female Students Only",
        "verified": True,
        "description": "Planning a peaceful workation/trip to Gokarna for beach walks, cafe hopping and pottery. Looking for 2 female college buddies to share safety-verified accommodation."
    },
    {
        "id": "pool-103",
        "creator_name": "Tanmay Deshmukh",
        "college": "COEP Pune",
        "destination": "Hampi Bicycle & Architecture Expedition",
        "date_range": "Oct 24 - Oct 27",
        "type": "College Squad",
        "seats_total": 6,
        "seats_left": 3,
        "cost_estimate": "₹500 / day covering rented mopeds & homestay split",
        "gender_pref": "Open to All Students",
        "verified": True,
        "description": "Exploring Hampi ruins on mopeds and coracle boats. We love photography, bouldering, and historical architecture. Low-budget hostel booking already locked in Hospet!"
    },
    {
        "id": "pool-104",
        "creator_name": "Pooja Verma",
        "college": "BHU Varanasi",
        "destination": "Varanasi Dawn Boat & Street Food Pod",
        "date_range": "Every Weekend",
        "type": "Local Guide Pod",
        "seats_total": 8,
        "seats_left": 4,
        "cost_estimate": "₹120 / student for private e-boat sunrise tour",
        "gender_pref": "Open to All Students",
        "verified": True,
        "description": "We are local BHU tourism student ambassadors. Join our sunrise boat group from Assi to Manikarnika Ghat with free student historical commentary and kachori breakfast!"
    }
]


class BuddyService:
    def __init__(self):
        self._lock = threading.Lock()
        self._pools: List[Dict[str, Any]] = [p.copy() for p in INITIAL_POOLS]

    def list_pools(self, category: str = "all") -> List[Dict[str, Any]]:
        with self._lock:
            cat = category.lower()
            if cat == "girls":
                return [p for p in self._pools if "girls" in p["type"].lower()]
            elif cat == "trek":
                return [p for p in self._pools if "trek" in p["type"].lower() or "trek" in p["destination"].lower()]
            elif cat == "squad":
                return [p for p in self._pools if "squad" in p["type"].lower() or "college" in p["type"].lower()]
            return list(self._pools)

    def create_pool(
        self,
        creator_name: str,
        college: str,
        destination: str,
        date_range: str,
        pool_type: str = "College Squad",
        seats_total: int = 4,
        cost_estimate: str = "Split equally",
        gender_pref: str = "Open to All Students",
        description: str = ""
    ) -> Dict[str, Any]:
        with self._lock:
            new_id = f"pool-{int(time.time() * 1000)}"
            seats = max(2, int(seats_total))
            pool_entry = {
                "id": new_id,
                "creator_name": creator_name.strip(),
                "college": college.strip(),
                "destination": destination.strip(),
                "date_range": date_range.strip(),
                "type": pool_type,
                "seats_total": seats,
                "seats_left": seats - 1,
                "cost_estimate": cost_estimate.strip() or "Split equally",
                "gender_pref": gender_pref,
                "verified": True,
                "description": description.strip() or f"Looking for student buddies to explore {destination} together and split costs!"
            }
            self._pools.insert(0, pool_entry)
            return pool_entry

    def join_pool(self, pool_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            for pool in self._pools:
                if pool["id"] == pool_id:
                    if pool["seats_left"] > 0:
                        pool["seats_left"] -= 1
                        return {
                            "success": True,
                            "seats_left": pool["seats_left"],
                            "creator_name": pool["creator_name"],
                            "message": f"Successfully joined {pool['creator_name']}'s pool! A connect token has been generated."
                        }
                    else:
                        return {
                            "success": False,
                            "message": "This travel pool is already full."
                        }
            return None
