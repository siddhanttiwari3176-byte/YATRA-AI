"""
YATRA AI - Services Package
Smart India Hackathon 2026 (SIH 2026 - Problem Statement SIH26204)
"""
