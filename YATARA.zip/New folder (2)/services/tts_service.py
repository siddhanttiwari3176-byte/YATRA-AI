"""
YATRA AI - Text-to-Speech (TTS) Service
Uses gTTS (Google Text-to-Speech) in Python to generate streaming audio for Indian language phrasebooks.
"""

import io
from typing import Optional

class TTSService:
    @staticmethod
    def generate_speech_audio(text: str, lang_code: str = "hi") -> Optional[io.BytesIO]:
        """
        Generates MP3 audio buffer using gTTS in Python.
        Supported Indian languages in gTTS: 'hi', 'ta', 'bn', 'mr', 'gu', 'en'.
        """
        try:
            from gtts import gTTS

            lang_map = {
                "hi": "hi",
                "ta": "ta",
                "bn": "bn",
                "mr": "mr",
                "gu": "gu",
                "en": "en"
            }
            target_lang = lang_map.get(lang_code, "hi")

            tts = gTTS(text=text, lang=target_lang, slow=False)
            fp = io.BytesIO()
            tts.write_to_fp(fp)
            fp.seek(0)
            return fp
        except Exception as e:
            # If offline or rate limited, return None so client-side fallback triggers
            print(f"[TTSService Warning] gTTS generation error: {e}")
            return None
