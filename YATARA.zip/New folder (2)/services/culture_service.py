"""
YATRA AI - Culture Service
Provides indigenous artisan profiles, heritage gems, and 5-language phrasebooks.
"""

from typing import List, Dict, Any

CULTURAL_GEMS = [
    {
        "id": "gem-1",
        "name": "Channapatna Wooden Toy Village",
        "location": "Ramanagara District, Karnataka",
        "category": "Indigenous Artisans",
        "badge": "GI Tagged Heritage",
        "image": "https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?auto=format&fit=crop&w=700&q=80",
        "description": "Home to 3,000+ artisans turning sustainable ivory wood into non-toxic lacquered toys using natural vegetable dyes since Tipu Sultan's era.",
        "student_impact": "Direct artisan workshop bookings eliminate middle-men, ensuring 85% revenue goes directly into artisan women's bank accounts.",
        "price": "₹150 for 1-hr live lathe craft workshop",
        "contact": "Artisan Co-Op: +91 80 2725 4321"
    },
    {
        "id": "gem-2",
        "name": "Majuli Island Mask Making & Satras",
        "location": "Brahmaputra River, Assam",
        "category": "Folk Arts",
        "badge": "World's Largest River Island",
        "image": "https://images.unsplash.com/photo-1609137144813-7d9921338f24?auto=format&fit=crop&w=700&q=80",
        "description": "Ancient Vaishnavite monasteries where monks sculpt biodegradable bamboo and cow dung theatrical masks used in 500-year-old Bhaona dances.",
        "student_impact": "Students stay at monastery guest huts for ₹300/night and help digitize ancient Assamese palm-leaf manuscripts.",
        "price": "₹300/night community stay",
        "contact": "Samaguri Satra: +91 9435 092 114"
    },
    {
        "id": "gem-3",
        "name": "Chettinad 1,000-Window Heritage Mansions",
        "location": "Sivaganga District, Tamil Nadu",
        "category": "Hidden Heritage",
        "badge": "Architectural Marvel",
        "image": "https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=700&q=80",
        "description": "Magnificent 19th-century merchant mansions built with Burmese teak, Italian marble, and Belgian mirrors alongside Athangudi handmade tiles.",
        "student_impact": "Architecture and design students receive free entry for sketch study tours by coordinating with the local heritage preservation trust.",
        "price": "₹50 entry / Free for Architecture IDs",
        "contact": "Chettinad Heritage Trust: +91 4565 241 002"
    },
    {
        "id": "gem-4",
        "name": "Lonar Geothermal Meteorite Crater Lake",
        "location": "Buldhana District, Maharashtra",
        "category": "Hidden Heritage",
        "badge": "Ramsar Eco-Site",
        "image": "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=700&q=80",
        "description": "The world's only hyper-velocity impact crater formed 50,000 years ago in basalt rock, harboring both saline and alkaline distinct microbial zones.",
        "student_impact": "Geology and biology students guide weekend backpacker walking groups to fund local school lake preservation clubs.",
        "price": "Free public access with eco-pledge",
        "contact": "Forest Range Office: 07260-221245"
    },
    {
        "id": "gem-5",
        "name": "Old Delhi Spice & Street Food Walk",
        "location": "Chandni Chowk & Khari Baoli, Delhi",
        "category": "Street Food Walks",
        "badge": "Asia's Largest Spice Market",
        "image": "https://images.unsplash.com/photo-1596797038530-2c107229654b?auto=format&fit=crop&w=700&q=80",
        "description": "Wander through 400-year-old spice lanes of Khari Baoli, savor historic Paranthe Wali Gali flatbreads, and sample Daulat ki Chaat.",
        "student_impact": "Student food ambassadors guide budget foodies through heritage alleys, keeping costs strictly under ₹250 per bellyful.",
        "price": "₹200 average food tasting budget",
        "contact": "Delhi Heritage Walk: +91 11 2327 9800"
    },
    {
        "id": "gem-6",
        "name": "Blue Pottery & Clay Masters of Kot Jewar",
        "location": "Jaipur Rural, Rajasthan",
        "category": "Indigenous Artisans",
        "badge": "Vocal for Local",
        "image": "https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=700&q=80",
        "description": "Traditional Rajasthani turquoise glazed ceramic craft that uses no clay—made entirely from quartz powder, raw glass, and gum.",
        "student_impact": "Student-run direct marketplace connect artisans directly to pan-India youth hostel decor projects without middlemen cuts.",
        "price": "₹250 for ceramic painting session",
        "contact": "Kripal Kumbh Rural Guild: +91 141 220 1127"
    }
]

PHRASEBOOK_DATA = {
    "hi": {
        "name": "Hindi (हिन्दी)",
        "greeting": "नमस्ते (Namaste)",
        "phrases": [
            {"id": "hi-1", "en": "How much does this cost?", "native": "यह कितने का है?", "roman": "Yeh kitne ka hai?", "tip": "Always polite for asking prices in markets and autos."},
            {"id": "hi-2", "en": "Is there a student discount?", "native": "क्या यहाँ छात्रों के लिए छूट है?", "roman": "Kya yahan chhaatron ke liye chhoot hai?", "tip": "Show your college ID card immediately."},
            {"id": "hi-3", "en": "Where is the nearest bus station?", "native": "नज़दीकी बस स्टैंड कहाँ है?", "roman": "Nazdeeki bus stand kahan hai?", "tip": "Locals are very helpful with bus routes."},
            {"id": "hi-4", "en": "Please make the food less spicy.", "native": "कृपया खाना कम तीखा बनाएं।", "roman": "Kripya khana kam teekha banayein.", "tip": "Essential for street food carts."},
            {"id": "hi-5", "en": "Please help, I need emergency assistance.", "native": "कृपया मदद करें, मुझे आपातकालीन सहायता चाहिए।", "roman": "Kripya madad karein, mujhe aapatkaleen sahayata chahiye.", "tip": "Dial 112 or 1363 for tourism police."}
        ]
    },
    "ta": {
        "name": "Tamil (தமிழ்)",
        "greeting": "வணக்கம் (Vanakkam)",
        "phrases": [
            {"id": "ta-1", "en": "How much does this cost?", "native": "இது என்ன விலை?", "roman": "Idhu enna vilai?", "tip": "Use at bus stands and tea stalls."},
            {"id": "ta-2", "en": "Is there a student discount?", "native": "மாணவர்களுக்கு தள்ளுபடி உண்டா?", "roman": "Maanavargalukku thallupadi undaa?", "tip": "State express buses have concessions."},
            {"id": "ta-3", "en": "Where is the bus stop?", "native": "பேருந்து நிறுத்தம் எங்கே?", "roman": "Perundhu niruttham engey?", "tip": "Look for government bus shelters."},
            {"id": "ta-4", "en": "One cup of filter coffee, please.", "native": "ஒரு கப் ஃபில்டர் காபி கொடுங்க.", "roman": "Oru cup filter coffee kodunga.", "tip": "The soul of South Indian travel."},
            {"id": "ta-5", "en": "Please help me.", "native": "தயவுசெய்து எனக்கு உதவுங்கள்.", "roman": "Dayavu seidhu enakku udhavungal.", "tip": "Emergency support phrase."}
        ]
    },
    "bn": {
        "name": "Bengali (বাংলা)",
        "greeting": "নমস্কার (Nomoshkar)",
        "phrases": [
            {"id": "bn-1", "en": "How much does this cost?", "native": "এটার দাম কত?", "roman": "Etar daam koto?", "tip": "Perfect for Kolkata trams and street markets."},
            {"id": "bn-2", "en": "Is there a student discount?", "native": "ছাত্রদের জন্য কোনো ছাড় আছে কি?", "roman": "Chhatroder jonyo kono chhar aachhe ki?", "tip": "Valid for museum and tram passes."},
            {"id": "bn-3", "en": "Where can I get good local food?", "native": "ভালো স্থানীয় খাবার কোথায় পাওয়া যাবে?", "roman": "Bhalo sthaniya khabar kothay pawa jabe?", "tip": "Ask for authentic mishti & fish curry."},
            {"id": "bn-4", "en": "Which way goes to the railway station?", "native": "স্টেশনে কোন পথ দিয়ে যায়?", "roman": "Station-e kon poth diye jaay?", "tip": "Direction inquiry."},
            {"id": "bn-5", "en": "Please help me.", "native": "আমাকে একটু সাহায্য করুন।", "roman": "Amake ektu sahajjo korun.", "tip": "Emergency request."}
        ]
    },
    "mr": {
        "name": "Marathi (मराठी)",
        "greeting": "नमस्कार (Namaskar)",
        "phrases": [
            {"id": "mr-1", "en": "How much does this cost?", "native": "हे किती रुपयांना आहे?", "roman": "He kiti rupayanna aahe?", "tip": "Used across Maharashtra forts & Pune markets."},
            {"id": "mr-2", "en": "Is there a student discount?", "native": "विद्यार्थ्यांसाठी काही सवलत आहे का?", "roman": "Vidyarthyaansathi kahi savlat aahe ka?", "tip": "Show college ID for ST bus & fort passes."},
            {"id": "mr-3", "en": "Where does this bus go?", "native": "ही बस कुठे जाते?", "roman": "Hee bus kuthe jaate?", "tip": "Check red MSRTC buses."},
            {"id": "mr-4", "en": "Give one hot Vada Pav, please.", "native": "एक गरम वडा पाव द्या ना.", "roman": "Ek garam vada pav dya na.", "tip": "The ultimate student budget meal (₹15)."},
            {"id": "mr-5", "en": "Please help me urgently.", "native": "कृपया मला तातडीने मदत करा.", "roman": "Krupaya mala taatadineey madad kara.", "tip": "Emergency phrase."}
        ]
    },
    "gu": {
        "name": "Gujarati (ગુજરાતી)",
        "greeting": "નમસ્તે (Kem Cho / Namaste)",
        "phrases": [
            {"id": "gu-1", "en": "How much does this cost?", "native": "આ કેટલા રૂપિયાનું છે?", "roman": "Aa ketla rupiya nu chhe?", "tip": "Standard market inquiry."},
            {"id": "gu-2", "en": "Is there a student discount?", "native": "વિદ્યાર્થીઓ માટે કોઈ ડિસ્કાઉન્ટ છે?", "roman": "Vidyarthio maate koi discount chhe?", "tip": "Ask at heritage stepwells & museums."},
            {"id": "gu-3", "en": "Where is the best Gujarati Thali?", "native": "સૌથી સારી ગુજરાતી થાળી ક્યાં મળશે?", "roman": "Sauthi saari Gujarati thali kyan malshe?", "tip": "Unlimited student feasts!" },
            {"id": "gu-4", "en": "Please show me the road.", "native": "મને રસ્તો બતાવો ને.", "roman": "Mane rasto bataavo ne.", "tip": "Friendly direction inquiry."},
            {"id": "gu-5", "en": "I need assistance.", "native": "મને મદદની જરૂર છે.", "roman": "Mane madad ni jaroor chhe.", "tip": "Emergency assistance."}
        ]
    }
}


class CultureService:
    @staticmethod
    def get_gems(category: str = "all") -> List[Dict[str, Any]]:
        if category == "all" or not category:
            return list(CULTURAL_GEMS)
        return [g for g in CULTURAL_GEMS if g["category"].lower() == category.lower()]

    @staticmethod
    def get_gem_by_id(gem_id: str) -> Dict[str, Any]:
        for g in CULTURAL_GEMS:
            if g["id"] == gem_id:
                return g
        return None

    @staticmethod
    def get_phrasebook(lang_code: str = "hi") -> Dict[str, Any]:
        return PHRASEBOOK_DATA.get(lang_code, PHRASEBOOK_DATA["hi"])

    @staticmethod
    def get_all_phrasebooks() -> Dict[str, Any]:
        return PHRASEBOOK_DATA
