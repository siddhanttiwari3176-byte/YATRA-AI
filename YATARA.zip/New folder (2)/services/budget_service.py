"""
YATRA AI - Budget Service
Calculates real-time expense breakdowns, group splits, and student concession savings.
"""

from typing import Dict, Any

class BudgetService:
    @staticmethod
    def calculate_budget(
        total_budget: float = 6000.0,
        travelers: int = 3,
        days: int = 4,
        stay_type: str = "hostel"
    ) -> Dict[str, Any]:
        total_budget = max(500.0, float(total_budget))
        travelers = max(1, int(travelers))
        days = max(1, int(days))

        # Weight factors
        stay_ratio = 0.28
        if stay_type == "homestay":
            stay_ratio = 0.32
        elif stay_type == "budget-hotel":
            stay_ratio = 0.38

        transit_ratio = 0.28
        food_ratio = 0.24
        activity_ratio = 0.10
        emergency_ratio = 0.10

        total_weight = stay_ratio + transit_ratio + food_ratio + activity_ratio + emergency_ratio

        stay_cost = round(total_budget * (stay_ratio / total_weight))
        transit_cost = round(total_budget * (transit_ratio / total_weight))
        food_cost = round(total_budget * (food_ratio / total_weight))
        activity_cost = round(total_budget * (activity_ratio / total_weight))
        emergency_cost = round(total_budget * (emergency_ratio / total_weight))

        per_student_total = round(total_budget / travelers)
        per_student_daily = round(per_student_total / days)

        return {
            "total_budget": total_budget,
            "travelers": travelers,
            "days": days,
            "stay_type": stay_type,
            "per_student_share": per_student_total,
            "per_student_daily": per_student_daily,
            "breakdown": {
                "stays": stay_cost,
                "transit": transit_cost,
                "food": food_cost,
                "activities": activity_cost,
                "emergency_buffer": emergency_cost
            },
            "chart_data": {
                "labels": ["Stays & Hostels", "Transit & Cabs", "Food & Chai", "Passes & Activities", "Emergency Buffer"],
                "values": [stay_cost, transit_cost, food_cost, activity_cost, emergency_cost],
                "colors": ["#FF6500", "#0D9488", "#FFB200", "#1E3E62", "#10B981"]
            },
            "student_concession_applied": "50% discount on ASI monuments & ordinary state transit"
        }
