"""
YATRA AI - Chatbot Service
Powers 'Yatra Bot' AI responses, emergency SOS routing, and student travel intelligence.
"""

from typing import Dict, Any, List

CHAT_KNOWLEDGE = [
    {
        "keywords": ["sos", "emergency", "police", "help", "helpline", "danger", "safe"],
        "is_sos": True,
        "response": (
            "🚨 **OFFICIAL 24x7 TOURIST HELPLINES IN INDIA:**\n\n"
            "• **National Tourism Helpline**: **1363** (Toll-Free, 12 languages supported)\n"
            "• **Unified Emergency Services**: **112** (Police, Fire, Ambulance)\n"
            "• **Women Helpline**: **1091** or **181**\n"
            "• **Railway Protection Force (RPF)**: **139** (For assistance on trains/stations)\n\n"
            "📍 *YATRA Safety Tip: Share your live location with your designated buddy pool before setting off on remote hikes.*"
        )
    },
    {
        "keywords": ["discount", "edupass", "id card", "student card", "asi", "cheap"],
        "is_sos": False,
        "response": (
            "🎓 **TOP STUDENT TRAVEL DISCOUNTS IN BHARAT:**\n\n"
            "1. **ASI Heritage Monuments**: Under ASI guidelines, Indian school/college students often receive free entry or tickets at just **₹25** (vs ₹500 for foreign tourists / full adult fare). Keep your College ID handy!\n"
            "2. **IRCTC Student Concession**: 50% concession in Second/Sleeper class for traveling between hometown and educational institution.\n"
            "3. **Hostels & Stays**: Chains like The Hosteller, Zostel, and goSTOPS provide **10-20% off** student rates when booked via YATRA EduPass integration.\n"
            "4. **Air Travel**: Air India & IndiGo offer **up to 25% base fare discount** + 25kg extra baggage allowance for verified students."
        )
    },
    {
        "keywords": ["budget", "himachal", "spiti", "kasol", "manali"],
        "is_sos": False,
        "response": (
            "🏔️ **POCKET-FRIENDLY HIMACHAL STUDENT BLUEPRINT (₹3,500 - ₹5,000 for 4 Days):**\n\n"
            "• **Transit**: Take Delhi/Chandigarh to Bhuntar via HRTC ordinary state bus (~₹650) instead of private Volvos (~₹1,500).\n"
            "• **Stay**: Backpacker dorm beds in Kasol/Old Manali cost ₹350 - ₹500/night.\n"
            "• **Food**: Savor local Siddu, Thukpa, and Dhaba thalis for ₹120 - ₹180.\n"
            "• **Trek**: Kheerganga or Bijli Mahadev can be done self-guided without paying ₹2,000 agency fees if you join a YATRA student buddy pool!"
        )
    },
    {
        "keywords": ["hampi", "ruins", "cycle", "karnataka"],
        "is_sos": False,
        "response": (
            "🏛️ **HAMPI ON A SHOESTRING (Under ₹900/day):**\n\n"
            "• Rent a geared bicycle near Virupaksha temple for **₹100/day**.\n"
            "• Stay across the river in Sanapur/Anegundi or near Hospet station for budget dorms (₹400/night).\n"
            "• Don't miss the free sunrise at Matanga Hill and golden hour sunset at Hemakuta Hill!\n"
            "• Food: Banana leaf South Indian meals at local messes for ₹80-₹120 unlimited."
        )
    },
    {
        "keywords": ["varanasi", "kashi", "boat", "ghat", "food"],
        "is_sos": False,
        "response": (
            "🪔 **VARANASI EXPERIENCES NOT TO MISS:**\n\n"
            "• **Morning**: 5:30 AM Subah-e-Banaras at Assi Ghat (Free classical music & yoga).\n"
            "• **Boat Ride**: Take a shared rowing or e-boat (₹100-₹150/head). Never pay more than ₹300 individually!\n"
            "• **Food Crawl**: Ram Bhandar kachori at 8 AM, Blue Lassi shop, and Tamatar Chaat at Kashi Chaat Bhandar.\n"
            "• **Evening**: Arrive at Dashashwamedh Ghat by 6:00 PM for front-row view of the Ganga Aarti."
        )
    }
]


class ChatbotService:
    @staticmethod
    def answer_query(user_message: str) -> Dict[str, Any]:
        msg_lower = user_message.lower().strip()

        for item in CHAT_KNOWLEDGE:
            if any(k in msg_lower for k in item["keywords"]):
                return {
                    "response": item["response"],
                    "is_sos": item["is_sos"],
                    "category": "knowledge_match"
                }

        # Conversational fallbacks
        if any(w in msg_lower for w in ["hello", "hi", "namaste", "hey"]):
            return {
                "response": (
                    "Namaste! 🙏 I am **Yatra Bot**, your AI companion for SIH 2026. How can I help your student travels today? You can ask about:\n\n"
                    "• Student discounts & ASI tickets\n"
                    "• 24x7 Emergency Helplines (1363 / 112)\n"
                    "• Low-cost itineraries for Himachal, Hampi, Varanasi\n"
                    "• Finding fellow student travel buddies"
                ),
                "is_sos": False,
                "category": "greeting"
            }

        if any(w in msg_lower for w in ["train", "railway", "irctc"]):
            return {
                "response": (
                    "🚆 **IRCTC Student Concession Hack:**\n"
                    "Under Indian Railways rules, students of recognized educational institutions can claim **50% concession** in 2nd and Sleeper classes between home and college, or on educational tours. Submit an IRCTC concession order certified by your college dean!"
                ),
                "is_sos": False,
                "category": "railways"
            }

        return {
            "response": (
                f"✨ I'm analyzing **'{user_message}'** through the **YATRA AI Student Knowledge Graph**.\n\n"
                "For customized multi-day schedules, check out our **AI Planner** tab, or find peers in the **Buddy Pools** section!\n\n"
                "Need urgent help? Call India's 24x7 Tourist Helpline at **1363** toll-free."
            ),
            "is_sos": False,
            "category": "general"
        }
