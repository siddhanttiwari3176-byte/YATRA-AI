/**
 * YATRA AI - Main Application Coordinator & Culture Hub Controller
 * Handles tabs, multilingual phrasebook, audio synthesis, student verification, and notifications.
 */

const YatraApp = {
  activeLanguage: 'hi',
  isStudentVerified: false,
  verifiedStudentData: null,

  init() {
    // Initialize child modules
    if (window.YatraPlanner) window.YatraPlanner.init();
    if (window.YatraBuddy) window.YatraBuddy.init();
    if (window.YatraBudget) window.YatraBudget.init();
    if (window.YatraBot) window.YatraBot.init();

    // Leaflet map initialization
    setTimeout(() => {
      if (window.yatraMapInstance) {
        window.yatraMapInstance.init();
      }
    }, 200);

    this.bindNavigation();
    this.bindHeroSearch();
    this.renderCulturalGems('all');
    this.bindCultureFilters();
    this.renderPhrasebook('hi');
    this.bindPhrasebookLanguages();
    this.bindEduPassModal();
  },

  // Toast Notification System
  showToast(message, type = 'info') {
    const toast = document.getElementById('toastNotification');
    const toastMsg = document.getElementById('toastMessage');
    const toastIcon = document.getElementById('toastIcon');
    if (!toast || !toastMsg) return;

    toastMsg.textContent = message;

    if (type === 'success') {
      toast.className = 'fixed bottom-5 left-1/2 -translate-x-1/2 z-50 bg-emerald-900 text-emerald-100 px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border border-emerald-500/40 text-sm font-medium transition-all duration-300';
      if (toastIcon) toastIcon.className = 'fas fa-circle-check text-emerald-400 text-base';
    } else if (type === 'error') {
      toast.className = 'fixed bottom-5 left-1/2 -translate-x-1/2 z-50 bg-red-900 text-red-100 px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border border-red-500/40 text-sm font-medium transition-all duration-300';
      if (toastIcon) toastIcon.className = 'fas fa-circle-exclamation text-red-400 text-base';
    } else {
      toast.className = 'fixed bottom-5 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-slate-100 px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border border-slate-700 text-sm font-medium transition-all duration-300';
      if (toastIcon) toastIcon.className = 'fas fa-info-circle text-orange-400 text-base';
    }

    toast.classList.remove('hidden', 'opacity-0', 'translate-y-4');
    toast.classList.add('opacity-100', 'translate-y-0');

    setTimeout(() => {
      toast.classList.add('opacity-0', 'translate-y-4');
      setTimeout(() => toast.classList.add('hidden'), 300);
    }, 4000);
  },

  // Navigation and Smooth Scrolling
  bindNavigation() {
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const mobileNav = document.getElementById('mobileNav');
    if (mobileMenuBtn && mobileNav) {
      mobileMenuBtn.addEventListener('click', () => {
        mobileNav.classList.toggle('hidden');
      });
    }

    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', (e) => {
        if (mobileNav) mobileNav.classList.add('hidden');
        const targetId = e.currentTarget.getAttribute('href');
        if (targetId && targetId.startsWith('#')) {
          const targetElem = document.querySelector(targetId);
          if (targetElem) {
            e.preventDefault();
            targetElem.scrollIntoView({ behavior: 'smooth' });
          }
        }
      });
    });
  },

  // Hero AI Natural Language Search Bar
  bindHeroSearch() {
    const searchForm = document.getElementById('heroSearchForm');
    const searchInput = document.getElementById('heroSearchInput');

    if (searchForm && searchInput) {
      searchForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const query = searchInput.value.trim().toLowerCase();
        if (!query) return;

        let matchedKey = 'himachal';
        if (query.includes('hampi') || query.includes('karnataka') || query.includes('ruins')) {
          matchedKey = 'hampi';
        } else if (query.includes('varanasi') || query.includes('kashi') || query.includes('ghat')) {
          matchedKey = 'varanasi';
        } else if (query.includes('rishikesh') || query.includes('rafting')) {
          matchedKey = 'rishikesh';
        } else if (query.includes('meghalaya') || query.includes('shillong') || query.includes('cherrapunji')) {
          matchedKey = 'meghalaya';
        } else if (query.includes('gokarna') || query.includes('beach')) {
          matchedKey = 'gokarna';
        }

        window.YatraPlanner.selectAndGenerate(matchedKey);
      });
    }

    // Preset search query chips
    document.querySelectorAll('.hero-search-chip').forEach(chip => {
      chip.addEventListener('click', (e) => {
        const query = e.currentTarget.dataset.query;
        if (searchInput) searchInput.value = query;
        if (searchForm) {
          searchForm.dispatchEvent(new Event('submit'));
        }
      });
    });
  },

  // Culture Hub - Filter Gems
  bindCultureFilters() {
    const buttons = document.querySelectorAll('.culture-filter-btn');
    buttons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        buttons.forEach(b => {
          b.classList.remove('bg-orange-600', 'text-white');
          b.classList.add('bg-white', 'text-slate-700', 'border', 'border-slate-200');
        });
        e.currentTarget.classList.add('bg-orange-600', 'text-white');
        e.currentTarget.classList.remove('bg-white', 'text-slate-700', 'border', 'border-slate-200');

        const cat = e.currentTarget.dataset.category;
        this.renderCulturalGems(cat);
      });
    });
  },

  renderCulturalGems(category) {
    const container = document.getElementById('culturalGemsContainer');
    if (!container) return;

    let items = YATRA_DATA.culturalHub;
    if (category !== 'all') {
      items = items.filter(item => item.category === category);
    }

    container.innerHTML = '';

    items.forEach(gem => {
      const card = document.createElement('div');
      card.className = 'group bg-white rounded-2xl overflow-hidden border border-slate-200/80 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between';

      card.innerHTML = `
        <div>
          <div class="relative h-48 overflow-hidden">
            <img src="${gem.image}" alt="${gem.name}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
            <div class="absolute top-3 left-3 flex flex-col gap-1">
              <span class="bg-slate-900/80 backdrop-blur-md text-white text-[11px] font-semibold px-2.5 py-1 rounded-full">
                ${gem.category}
              </span>
              <span class="bg-orange-600/90 backdrop-blur-md text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                ${gem.badge}
              </span>
            </div>
          </div>

          <div class="p-5">
            <div class="text-xs font-semibold text-teal-700 mb-1">
              <i class="fas fa-location-dot mr-1"></i> ${gem.location}
            </div>
            <h4 class="text-lg font-bold text-slate-900 mb-2">${gem.name}</h4>
            <p class="text-xs text-slate-600 leading-relaxed mb-3">${gem.description}</p>
            
            <div class="p-2.5 rounded-xl bg-orange-50 border border-orange-100 text-[11px] text-orange-900 mb-2">
              <strong>🎓 Student & Community Impact:</strong> ${gem.studentImpact}
            </div>
          </div>
        </div>

        <div class="px-5 pb-5 pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
          <div>
            <span class="text-slate-400 block text-[10px]">Student Access</span>
            <span class="font-bold text-slate-800">${gem.price}</span>
          </div>
          <button onclick="YatraApp.showArtisanModal('${gem.id}')" 
            class="px-3 py-1.5 rounded-xl bg-slate-900 text-white hover:bg-orange-600 transition-colors font-semibold text-xs">
            Connect →
          </button>
        </div>
      `;

      container.appendChild(card);
    });
  },

  showArtisanModal(gemId) {
    const gem = YATRA_DATA.culturalHub.find(g => g.id === gemId);
    if (!gem) return;

    const modal = document.getElementById('artisanConnectModal');
    const content = document.getElementById('artisanModalContent');
    if (!modal || !content) return;

    content.innerHTML = `
      <div class="text-center mb-4">
        <span class="text-xs font-bold uppercase tracking-wider text-orange-600">${gem.category}</span>
        <h3 class="text-xl font-bold text-slate-900 mt-1">${gem.name}</h3>
        <p class="text-xs text-slate-500">${gem.location}</p>
      </div>

      <div class="space-y-3 text-xs text-slate-700 bg-slate-50 p-4 rounded-xl mb-4">
        <p><strong>Official Contact / Guild:</strong> ${gem.contact}</p>
        <p><strong>Student Concession:</strong> Free or 50% discount upon showing valid College ID.</p>
        <p><strong>Vocal For Local Initiative:</strong> All booking tokens are routed directly with 0% platform commission to support indigenous artisans.</p>
      </div>

      <div class="flex gap-2">
        <a href="tel:${gem.contact.replace(/[^0-9]/g, '')}" class="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold text-xs text-center">
          <i class="fas fa-phone mr-1"></i> Call Guild
        </a>
        <button onclick="document.getElementById('artisanConnectModal').classList.add('hidden')" class="flex-1 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl font-semibold text-xs">
          Close
        </button>
      </div>
    `;

    modal.classList.remove('hidden');
  },

  // Multilingual Phrasebook Widget
  bindPhrasebookLanguages() {
    const langBtns = document.querySelectorAll('.phrase-lang-btn');
    langBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        langBtns.forEach(b => {
          b.classList.remove('bg-slate-900', 'text-white');
          b.classList.add('bg-slate-100', 'text-slate-700');
        });
        e.currentTarget.classList.add('bg-slate-900', 'text-white');
        e.currentTarget.classList.remove('bg-slate-100', 'text-slate-700');

        const langCode = e.currentTarget.dataset.lang;
        this.activeLanguage = langCode;
        this.renderPhrasebook(langCode);
      });
    });
  },

  renderPhrasebook(langCode) {
    const container = document.getElementById('phrasebookList');
    const greetingContainer = document.getElementById('phraseGreeting');
    const data = YATRA_DATA.phrasebook[langCode];
    if (!container || !data) return;

    if (greetingContainer) {
      greetingContainer.innerHTML = `
        <div class="flex items-center gap-2 text-sm text-orange-600 font-bold">
          <i class="fas fa-hands-praying"></i> Local Greeting: <span class="text-slate-900 font-extrabold text-base">${data.greeting}</span>
        </div>
      `;
    }

    container.innerHTML = '';

    data.phrases.forEach((phrase, idx) => {
      const item = document.createElement('div');
      item.className = 'p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 hover:bg-orange-50/50 hover:border-orange-200 transition-colors flex flex-col justify-between';

      item.innerHTML = `
        <div class="flex items-start justify-between gap-2 mb-1.5">
          <span class="text-xs font-semibold text-slate-800">${phrase.en}</span>
          <button onclick="YatraApp.speakPhrase('${phrase.native.replace(/'/g, "\\'")}', '${langCode}')" 
            class="w-7 h-7 rounded-full bg-white hover:bg-orange-500 hover:text-white text-slate-600 border border-slate-200 flex items-center justify-center text-xs transition-colors shrink-0" 
            title="Listen Pronunciation">
            <i class="fas fa-volume-high"></i>
          </button>
        </div>

        <div class="text-base font-bold text-orange-600 mb-0.5">
          ${phrase.native}
        </div>

        <div class="text-[11px] font-mono text-slate-500 mb-1">
          "${phrase.roman}"
        </div>

        <div class="text-[10px] text-teal-800 font-medium">
          💡 ${phrase.tip}
        </div>
      `;

      container.appendChild(item);
    });
  },

  speakPhrase(text, langCode) {
    if (!('speechSynthesis' in window)) {
      this.showToast("Speech synthesis not supported in this browser.", "error");
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.85;

    // Map language codes to BCP 47
    const langMap = {
      'hi': 'hi-IN',
      'ta': 'ta-IN',
      'bn': 'bn-IN',
      'mr': 'mr-IN',
      'gu': 'gu-IN'
    };
    utterance.lang = langMap[langCode] || 'hi-IN';

    window.speechSynthesis.speak(utterance);
    this.showToast(`Pronouncing: "${text}"`, "info");
  },

  // EduPass Student Verification System
  bindEduPassModal() {
    const openBtn = document.getElementById('openEduPassBtn');
    const openBtnMobile = document.getElementById('openEduPassBtnMobile');
    const modal = document.getElementById('eduPassModal');
    const closeBtn = document.getElementById('closeEduPassBtn');
    const form = document.getElementById('eduPassForm');

    const openModal = () => {
      if (modal) modal.classList.remove('hidden');
    };

    if (openBtn) openBtn.addEventListener('click', openModal);
    if (openBtnMobile) openBtnMobile.addEventListener('click', openModal);
    if (closeBtn) closeBtn.addEventListener('click', () => modal.classList.add('hidden'));

    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const studentName = document.getElementById('eduName')?.value.trim();
        const collegeName = document.getElementById('eduCollege')?.value.trim();
        const studentId = document.getElementById('eduIdNumber')?.value.trim();

        if (!studentName || !collegeName || !studentId) {
          this.showToast("Please fill all details.", "error");
          return;
        }

        this.isStudentVerified = true;
        this.verifiedStudentData = { studentName, collegeName, studentId };

        // Update UI Badges
        const navBtnText = document.getElementById('eduPassBtnText');
        if (navBtnText) {
          navBtnText.innerHTML = `
            <span class="flex items-center gap-1.5">
              <i class="fas fa-badge-check text-teal-400"></i> ${studentName.split(' ')[0]} (EduPass)
            </span>
          `;
        }

        modal.classList.add('hidden');
        this.showToast(`🎓 Welcome ${studentName}! EduPass activated for ${collegeName}. 20% student perks unlocked!`, "success");
      });
    }
  }
};

document.addEventListener('DOMContentLoaded', () => {
  YatraApp.init();
});

window.YatraApp = YatraApp;
