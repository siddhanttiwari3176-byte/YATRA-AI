/**
 * YATRA AI - Smart Budget Tracker & Expense Splitter
 * Real-time Chart.js breakdown and student concession optimization.
 */

const YatraBudget = {
  chartInstance: null,

  init() {
    this.bindInputs();
    this.updateBudgetBreakdown();
  },

  bindInputs() {
    const inputs = ['totalBudgetInput', 'budgetTravelers', 'budgetDays', 'budgetStayType'];
    inputs.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('input', () => this.updateBudgetBreakdown());
        el.addEventListener('change', () => this.updateBudgetBreakdown());
      }
    });
  },

  updateBudgetBreakdown() {
    const totalBudget = parseFloat(document.getElementById('totalBudgetInput')?.value || '6000');
    const travelers = parseInt(document.getElementById('budgetTravelers')?.value || '3', 10);
    const days = parseInt(document.getElementById('budgetDays')?.value || '4', 10);
    const stayType = document.getElementById('budgetStayType')?.value || 'hostel';

    // Update display values
    const travelerVal = document.getElementById('budgetTravelerVal');
    if (travelerVal) travelerVal.textContent = `${travelers} ${travelers === 1 ? 'Student' : 'Students'}`;

    const daysVal = document.getElementById('budgetDaysVal');
    if (daysVal) daysVal.textContent = `${days} ${days === 1 ? 'Day' : 'Days'}`;

    // Ratio weights based on stay preference
    let stayRatio = 0.28;
    if (stayType === 'homestay') stayRatio = 0.32;
    if (stayType === 'budget-hotel') stayRatio = 0.38;

    const transitRatio = 0.28;
    const foodRatio = 0.24;
    const activityRatio = 0.10;
    const emergencyRatio = 0.10; // safety buffer

    // Normalize ratios to sum to 1
    const currentSum = stayRatio + transitRatio + foodRatio + activityRatio + emergencyRatio;
    const stayCost = Math.round(totalBudget * (stayRatio / currentSum));
    const transitCost = Math.round(totalBudget * (transitRatio / currentSum));
    const foodCost = Math.round(totalBudget * (foodRatio / currentSum));
    const activityCost = Math.round(totalBudget * (activityRatio / currentSum));
    const emergencyCost = Math.round(totalBudget * (emergencyRatio / currentSum));

    const perStudentTotal = Math.round(totalBudget / travelers);
    const perStudentPerDay = Math.round(perStudentTotal / days);

    // Update stats in UI
    const perStudentEl = document.getElementById('perStudentShare');
    if (perStudentEl) perStudentEl.textContent = `₹${perStudentTotal.toLocaleString('en-IN')}`;

    const perDayEl = document.getElementById('perStudentDaily');
    if (perDayEl) perDayEl.textContent = `₹${perStudentPerDay.toLocaleString('en-IN')}/day`;

    // Detailed breakdown list
    const stayEl = document.getElementById('budgetStayCost');
    if (stayEl) stayEl.textContent = `₹${stayCost.toLocaleString('en-IN')}`;

    const transitEl = document.getElementById('budgetTransitCost');
    if (transitEl) transitEl.textContent = `₹${transitCost.toLocaleString('en-IN')}`;

    const foodEl = document.getElementById('budgetFoodCost');
    if (foodEl) foodEl.textContent = `₹${foodCost.toLocaleString('en-IN')}`;

    const activityEl = document.getElementById('budgetActivityCost');
    if (activityEl) activityEl.textContent = `₹${activityCost.toLocaleString('en-IN')}`;

    const emergencyEl = document.getElementById('budgetEmergencyCost');
    if (emergencyEl) emergencyEl.textContent = `₹${emergencyCost.toLocaleString('en-IN')}`;

    // Render / Update Chart.js Donut
    this.renderChart([stayCost, transitCost, foodCost, activityCost, emergencyCost]);
  },

  renderChart(dataValues) {
    const canvas = document.getElementById('budgetDonutChart');
    if (!canvas || typeof Chart === 'undefined') return;

    const ctx = canvas.getContext('2d');

    const chartData = {
      labels: ['Stays & Hostels', 'Transit & Cabs', 'Food & Chai', 'Activities & Passes', 'Emergency Buffer'],
      datasets: [{
        data: dataValues,
        backgroundColor: [
          '#FF6500', // Saffron Stay
          '#0D9488', // Teal Transit
          '#FFB200', // Amber Food
          '#1E3E62', // Royal Blue Passes
          '#10B981'  // Emerald Emergency Buffer
        ],
        borderWidth: 3,
        borderColor: '#FFFFFF',
        hoverOffset: 6
      }]
    };

    if (this.chartInstance) {
      this.chartInstance.data = chartData;
      this.chartInstance.update();
    } else {
      this.chartInstance = new Chart(ctx, {
        type: 'doughnut',
        data: chartData,
        options: {
          responsive: true,
          maintainAspectRatio: false,
          cutout: '72%',
          plugins: {
            legend: {
              display: false
            },
            tooltip: {
              backgroundColor: '#0B192C',
              titleFont: { family: 'Outfit', size: 13 },
              bodyFont: { family: 'Plus Jakarta Sans', size: 12 },
              padding: 10,
              cornerRadius: 8,
              callbacks: {
                label: function(context) {
                  return ` ${context.label}: ₹${context.raw.toLocaleString('en-IN')}`;
                }
              }
            }
          }
        }
      });
    }
  }
};

window.YatraBudget = YatraBudget;
