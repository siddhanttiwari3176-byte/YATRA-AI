/**
 * YATRA AI - Yatra Bot (24x7 Student Tourist AI Assistant)
 * Provides real-time guidance, student discount hacks, and official 1363/112 SOS helplines.
 */

const YatraBot = {
  isOpen: false,

  init() {
    this.bindEvents();
  },

  bindEvents() {
    const toggleBtn = document.getElementById('chatToggleBtn');
    const closeBtn = document.getElementById('chatCloseBtn');
    const sendBtn = document.getElementById('chatSendBtn');
    const inputField = document.getElementById('chatInput');

    if (toggleBtn) {
      toggleBtn.addEventListener('click', () => this.toggleChat());
    }
    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.toggleChat(false));
    }
    if (sendBtn) {
      sendBtn.addEventListener('click', () => this.handleUserSend());
    }
    if (inputField) {
      inputField.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          this.handleUserSend();
        }
      });
    }

    // Quick suggestion chips
    document.querySelectorAll('.chat-chip').forEach(chip => {
      chip.addEventListener('click', (e) => {
        const query = e.currentTarget.textContent.trim();
        this.sendQuery(query);
      });
    });
  },

  toggleChat(forceState) {
    const chatModal = document.getElementById('chatWidgetContainer');
    const badge = document.getElementById('chatUnreadBadge');
    if (!chatModal) return;

    this.isOpen = typeof forceState === 'boolean' ? forceState : !this.isOpen;

    if (this.isOpen) {
      chatModal.classList.remove('hidden');
      if (badge) badge.classList.add('hidden');
      const input = document.getElementById('chatInput');
      if (input) setTimeout(() => input.focus(), 150);
    } else {
      chatModal.classList.add('hidden');
    }
  },

  sendQuery(text) {
    if (!this.isOpen) this.toggleChat(true);
    const input = document.getElementById('chatInput');
    if (input) input.value = text;
    this.handleUserSend();
  },

  handleUserSend() {
    const input = document.getElementById('chatInput');
    if (!input) return;
    const message = input.value.trim();
    if (!message) return;

    this.appendMessage(message, 'user');
    input.value = '';

    // Show typing animation
    this.showTypingIndicator();

    setTimeout(() => {
      this.hideTypingIndicator();
      const botResponse = this.generateBotResponse(message);
      this.appendMessage(botResponse, 'bot');
    }, 600);
  },

  generateBotResponse(userInput) {
    const lower = userInput.toLowerCase();

    // Check pre-configured knowledge base
    for (const item of YATRA_DATA.chatKnowledge) {
      if (item.keywords.some(kw => lower.includes(kw))) {
        return item.response;
      }
    }

    // Default conversational responses
    if (lower.includes('hello') || lower.includes('hi') || lower.includes('namaste')) {
      return `Namaste! 🙏 I am **Yatra Bot**, your AI companion for SIH 2026. How can I help your student travels today? You can ask about:\n\n• Student discounts & ASI tickets\n• 24x7 Emergency Helplines (1363)\n• Low-cost itineraries for Himachal, Hampi, Varanasi\n• Finding fellow student travel buddies`;
    }

    if (lower.includes('train') || lower.includes('irctc')) {
      return `🚆 **IRCTC Student Concession Hack:**\nUnder Indian Railways rules, students of recognized educational institutions can claim **50% concession** in 2nd and Sleeper classes between home and college, or on educational tours. Submit an IRCTC concession order certified by your college dean!`;
    }

    if (lower.includes('food') || lower.includes('eat')) {
      return `🍛 **Student Culinary Pro-Tip:**\nAlways ask for the **'Unlimited Thali'** or local student messes near university campus areas in tourist hubs (e.g., Banaras Hindu University in Varanasi, or university canteens in Dharamshala). Delicious hygienic meals for ₹70-₹120!`;
    }

    return `✨ I'm analyzing that through the **YATRA AI Student Knowledge Graph**.\n\nFor **${userInput}**, we recommend checking out our dynamic **AI Planner** in the tab above, or connecting with local verified student guides in the **Culture Hub**!\n\nNeed emergency support? Call India's 24x7 Tourist Helpline at **1363** toll-free.`;
  },

  appendMessage(content, sender) {
    const history = document.getElementById('chatHistory');
    if (!history) return;

    const msgWrapper = document.createElement('div');
    msgWrapper.className = `flex ${sender === 'user' ? 'justify-end' : 'justify-start'} mb-3`;

    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Format markdown bold & line breaks
    let formattedText = content
      .replace(/\n\n/g, '<br><br>')
      .replace(/\n/g, '<br>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/•/g, '&bull;');

    if (sender === 'user') {
      msgWrapper.innerHTML = `
        <div class="max-w-[85%] bg-orange-600 text-white p-3 rounded-2xl rounded-tr-xs text-xs shadow-sm">
          <p>${formattedText}</p>
          <div class="text-[10px] text-orange-200 text-right mt-1">${timeStr}</div>
        </div>
      `;
    } else {
      msgWrapper.innerHTML = `
        <div class="flex items-start gap-2 max-w-[90%]">
          <div class="w-7 h-7 rounded-full bg-slate-900 text-orange-400 flex items-center justify-center text-xs shrink-0 mt-0.5 shadow">
            <i class="fas fa-robot"></i>
          </div>
          <div class="bg-white text-slate-800 p-3 rounded-2xl rounded-tl-xs text-xs border border-slate-200/80 shadow-sm">
            <div class="leading-relaxed">${formattedText}</div>
            <div class="text-[10px] text-slate-400 mt-1.5 flex items-center justify-between">
              <span>Yatra AI Bot</span>
              <span>${timeStr}</span>
            </div>
          </div>
        </div>
      `;
    }

    history.appendChild(msgWrapper);
    history.scrollTop = history.scrollHeight;
  },

  showTypingIndicator() {
    const history = document.getElementById('chatHistory');
    if (!history) return;

    const indicator = document.createElement('div');
    indicator.id = 'chatTypingIndicator';
    indicator.className = 'flex items-center gap-2 mb-3';
    indicator.innerHTML = `
      <div class="w-7 h-7 rounded-full bg-slate-900 text-orange-400 flex items-center justify-center text-xs shrink-0">
        <i class="fas fa-robot"></i>
      </div>
      <div class="bg-white border border-slate-200/80 p-2.5 rounded-2xl rounded-tl-xs text-xs shadow-sm flex items-center gap-1">
        <span class="w-1.5 h-1.5 bg-orange-500 rounded-full animate-bounce"></span>
        <span class="w-1.5 h-1.5 bg-orange-500 rounded-full animate-bounce [animation-delay:0.2s]"></span>
        <span class="w-1.5 h-1.5 bg-orange-500 rounded-full animate-bounce [animation-delay:0.4s]"></span>
      </div>
    `;
    history.appendChild(indicator);
    history.scrollTop = history.scrollHeight;
  },

  hideTypingIndicator() {
    const indicator = document.getElementById('chatTypingIndicator');
    if (indicator) indicator.remove();
  }
};

window.YatraBot = YatraBot;
