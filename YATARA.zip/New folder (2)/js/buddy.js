/**
 * YATRA AI - Student Travel Pool & Buddy Finder
 * Enables students to find travel companions, split cab/homestay expenses,
 * and verify college peers safely.
 */

const YatraBuddy = {
  pools: [],
  activeFilter: 'all',

  init() {
    this.pools = [...YATRA_DATA.initialBuddyPools];
    this.renderPools();
    this.bindEvents();
  },

  bindEvents() {
    // Filter buttons
    const filterButtons = document.querySelectorAll('.pool-filter-btn');
    filterButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        filterButtons.forEach(b => {
          b.classList.remove('bg-orange-600', 'text-white', 'shadow-md');
          b.classList.add('bg-white', 'text-slate-700', 'border', 'border-slate-200');
        });
        e.currentTarget.classList.add('bg-orange-600', 'text-white', 'shadow-md');
        e.currentTarget.classList.remove('bg-white', 'text-slate-700', 'border', 'border-slate-200');

        this.activeFilter = e.currentTarget.dataset.filter;
        this.renderPools();
      });
    });

    // Create pool form submission
    const createPoolForm = document.getElementById('createPoolForm');
    if (createPoolForm) {
      createPoolForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleCreatePool();
      });
    }
  },

  renderPools() {
    const container = document.getElementById('buddyPoolsList');
    if (!container) return;

    let filtered = this.pools;
    if (this.activeFilter === 'girls') {
      filtered = this.pools.filter(p => p.type.toLowerCase().includes('girls'));
    } else if (this.activeFilter === 'trek') {
      filtered = this.pools.filter(p => p.type.toLowerCase().includes('trek') || p.destination.toLowerCase().includes('trek'));
    } else if (this.activeFilter === 'squad') {
      filtered = this.pools.filter(p => p.type.toLowerCase().includes('squad') || p.type.toLowerCase().includes('college'));
    }

    container.innerHTML = '';

    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="col-span-full py-12 text-center text-slate-500">
          <i class="fas fa-users-slash text-4xl text-slate-300 mb-3 block"></i>
          <p class="font-medium text-base">No active pools found in this category.</p>
          <p class="text-xs text-slate-400 mt-1">Be the first student to create a pool for your university!</p>
        </div>
      `;
      return;
    }

    filtered.forEach(pool => {
      const card = document.createElement('div');
      card.className = 'bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm hover:shadow-md transition-all flex flex-col justify-between';

      const isGirlsOnly = pool.type.toLowerCase().includes('girls');
      const badgeColor = isGirlsOnly 
        ? 'bg-pink-100 text-pink-700 border-pink-200' 
        : 'bg-orange-100 text-orange-800 border-orange-200';

      card.innerHTML = `
        <div>
          <div class="flex items-start justify-between gap-3 mb-3">
            <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${badgeColor}">
              <i class="fas ${isGirlsOnly ? 'fa-shield-halved' : 'fa-users'}"></i> ${pool.type}
            </span>
            <div class="text-right">
              <span class="text-xs font-bold ${pool.seatsLeft > 0 ? 'text-emerald-600' : 'text-red-500'}">
                ${pool.seatsLeft > 0 ? `${pool.seatsLeft} of ${pool.seatsTotal} Seats Left` : 'Pool Full'}
              </span>
            </div>
          </div>

          <h4 class="text-lg font-bold text-slate-900 mb-1">${pool.destination}</h4>
          
          <div class="flex items-center gap-2 text-xs text-slate-500 mb-3">
            <span><i class="far fa-calendar-alt text-orange-500 mr-1"></i>${pool.dateRange}</span>
            <span>•</span>
            <span><i class="fas fa-venus-mars text-teal-600 mr-1"></i>${pool.genderPref}</span>
          </div>

          <p class="text-xs text-slate-600 mb-4 line-clamp-3 leading-relaxed">${pool.description}</p>
        </div>

        <div class="pt-4 border-t border-slate-100 mt-2">
          <div class="flex items-center justify-between mb-3 text-xs">
            <div class="flex items-center gap-2">
              <div class="w-8 h-8 rounded-full bg-slate-900 text-white font-bold flex items-center justify-center text-xs">
                ${pool.creatorName.charAt(0)}
              </div>
              <div>
                <p class="font-bold text-slate-800 flex items-center gap-1">
                  ${pool.creatorName}
                  ${pool.verified ? '<i class="fas fa-check-circle text-teal-500 text-[11px]" title="Verified Student ID"></i>' : ''}
                </p>
                <p class="text-[11px] text-slate-500">${pool.college}</p>
              </div>
            </div>
          </div>

          <div class="bg-slate-50 p-2.5 rounded-xl mb-3 text-xs flex items-center justify-between">
            <span class="text-slate-600 font-medium">Est. Split Share:</span>
            <span class="font-bold text-slate-900">${pool.costEstimate}</span>
          </div>

          <button onclick="YatraBuddy.requestJoin('${pool.id}')" 
            class="w-full py-2.5 px-4 rounded-xl font-semibold text-xs flex items-center justify-center gap-2 transition-colors ${
              pool.seatsLeft > 0 
                ? 'bg-slate-900 hover:bg-orange-600 text-white shadow-sm' 
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }" ${pool.seatsLeft === 0 ? 'disabled' : ''}>
            <i class="fas fa-user-plus"></i> ${pool.seatsLeft > 0 ? 'Request to Join Pool' : 'Pool Full'}
          </button>
        </div>
      `;

      container.appendChild(card);
    });
  },

  handleCreatePool() {
    const name = document.getElementById('poolCreatorName')?.value.trim();
    const college = document.getElementById('poolCollege')?.value.trim();
    const destination = document.getElementById('poolDestination')?.value.trim();
    const dateRange = document.getElementById('poolDates')?.value.trim();
    const type = document.getElementById('poolType')?.value || 'College Squad';
    const seatsTotal = parseInt(document.getElementById('poolSeats')?.value || '4', 10);
    const costEstimate = document.getElementById('poolCost')?.value.trim() || 'Split equally';
    const genderPref = document.getElementById('poolGenderPref')?.value || 'Open to All Students';
    const description = document.getElementById('poolDesc')?.value.trim();

    if (!name || !college || !destination || !dateRange) {
      if (window.YatraApp) window.YatraApp.showToast("Please fill all required fields!", "error");
      return;
    }

    const newPool = {
      id: `pool-${Date.now()}`,
      creatorName: name,
      college: college,
      destination: destination,
      dateRange: dateRange,
      type: type,
      seatsTotal: seatsTotal,
      seatsLeft: seatsTotal - 1,
      costEstimate: costEstimate,
      genderPref: genderPref,
      verified: true, // Verified via EduPass
      description: description || `Looking for ${seatsTotal - 1} enthusiastic student travel buddies to explore ${destination} together and split costs!`
    };

    this.pools.unshift(newPool);
    this.renderPools();

    // Close modal
    const modal = document.getElementById('createPoolModal');
    if (modal) modal.classList.add('hidden');

    // Reset form
    document.getElementById('createPoolForm')?.reset();

    if (window.YatraApp) {
      window.YatraApp.showToast("🎉 Travel pool created successfully! Verified badge attached.", "success");
    }
  },

  requestJoin(poolId) {
    const pool = this.pools.find(p => p.id === poolId);
    if (!pool || pool.seatsLeft <= 0) return;

    pool.seatsLeft -= 1;
    this.renderPools();

    if (window.YatraApp) {
      window.YatraApp.showToast(`Request sent to ${pool.creatorName}! A WhatsApp/Email connect token has been shared.`, "success");
    } else {
      alert(`Request sent to ${pool.creatorName}!`);
    }
  }
};

window.YatraBuddy = YatraBuddy;
