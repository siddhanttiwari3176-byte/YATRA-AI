/**
 * YATRA AI - Leaflet.js Interactive Mapping Controller
 * Plots dynamic route waypoints, day markers, and destination bounds.
 */

class YatraMapController {
  constructor(mapElementId = 'itineraryMap') {
    this.elementId = mapElementId;
    this.map = null;
    this.markersGroup = null;
    this.routeLine = null;
    this.currentDestination = null;
  }

  init() {
    const mapContainer = document.getElementById(this.elementId);
    if (!mapContainer) return;

    // Check if already initialized
    if (this.map) {
      this.map.invalidateSize();
      return;
    }

    // Default center on India
    this.map = L.map(this.elementId, {
      center: [22.3511, 78.6677],
      zoom: 5,
      zoomControl: true,
      scrollWheelZoom: false
    });

    // High quality light travel aesthetic tile layer (CartoDB Positron with labels)
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
      subdomains: 'abcd',
      maxZoom: 19
    }).addTo(this.map);

    this.markersGroup = L.featureGroup().addTo(this.map);

    // Initial overview pins across India
    this.plotOverviewDestinations();
  }

  plotOverviewDestinations() {
    if (!this.map || !this.markersGroup) return;
    this.markersGroup.clearLayers();
    if (this.routeLine) {
      this.map.removeLayer(this.routeLine);
      this.routeLine = null;
    }

    const destinations = YATRA_DATA.destinations;
    Object.keys(destinations).forEach(key => {
      const dest = destinations[key];
      const customIcon = L.divIcon({
        className: 'custom-map-marker-container',
        html: `<div class="custom-map-marker hub-marker" style="width: 32px; height: 32px;">📍</div>`,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
        popupAnchor: [0, -16]
      });

      const marker = L.marker(dest.coords, { icon: customIcon });
      const popupHtml = `
        <div class="p-3 max-w-xs">
          <div class="text-xs font-bold uppercase tracking-wider text-orange-600 mb-1">${dest.vibe}</div>
          <h4 class="font-bold text-slate-800 text-sm mb-1">${dest.name}</h4>
          <p class="text-xs text-slate-600 mb-2">${dest.tagline}</p>
          <div class="flex items-center justify-between pt-2 border-t border-slate-100 text-xs font-semibold text-slate-700">
            <span>₹${dest.baseCostPerDay}/day</span>
            <button onclick="window.YatraPlanner.selectAndGenerate('${key}')" class="text-orange-600 hover:text-orange-700 underline cursor-pointer">
              Plan Trip →
            </button>
          </div>
        </div>
      `;
      marker.bindPopup(popupHtml);
      this.markersGroup.addLayer(marker);
    });

    this.map.fitBounds(this.markersGroup.getBounds().pad(0.2));
  }

  renderDestinationItinerary(destKey, daysCount = 3) {
    if (!this.map || !this.markersGroup) this.init();
    
    const dest = YATRA_DATA.destinations[destKey];
    if (!dest) return;

    this.markersGroup.clearLayers();
    if (this.routeLine) {
      this.map.removeLayer(this.routeLine);
      this.routeLine = null;
    }

    const latLngs = [];
    const availableDays = dest.days.slice(0, daysCount);

    availableDays.forEach((dayData, index) => {
      const dayNum = index + 1;
      const coords = dayData.coords || dest.coords;
      latLngs.push(coords);

      const customIcon = L.divIcon({
        className: 'custom-map-marker-container',
        html: `<div class="custom-map-marker" style="width: 34px; height: 34px;">${dayNum}</div>`,
        iconSize: [34, 34],
        iconAnchor: [17, 17],
        popupAnchor: [0, -18]
      });

      const marker = L.marker(coords, { icon: customIcon });
      const popupHtml = `
        <div class="p-3 max-w-xs text-slate-800">
          <div class="bg-orange-500 text-white font-bold text-xs uppercase px-2 py-0.5 rounded-full inline-block mb-1">
            Day ${dayNum} Stop
          </div>
          <h4 class="font-bold text-sm mb-1">${dayData.title}</h4>
          <div class="text-xs text-slate-600 space-y-1 mb-2">
            <p><strong>AM:</strong> ${dayData.morning.activity.slice(0, 75)}...</p>
            <p><strong>PM:</strong> ${dayData.afternoon.activity.slice(0, 75)}...</p>
          </div>
          <div class="bg-teal-50 text-teal-800 text-[11px] p-1.5 rounded font-medium">
            🎯 Student Perk: ${dayData.morning.studentPerk}
          </div>
        </div>
      `;
      marker.bindPopup(popupHtml);
      this.markersGroup.addLayer(marker);
    });

    // Draw route polyline
    if (latLngs.length > 1) {
      this.routeLine = L.polyline(latLngs, {
        color: '#FF6500',
        weight: 4,
        opacity: 0.8,
        dashArray: '8, 8',
        lineCap: 'round'
      }).addTo(this.map);
    }

    // Fit map view to waypoints
    if (latLngs.length > 0) {
      if (latLngs.length === 1) {
        this.map.setView(latLngs[0], 12);
      } else {
        this.map.fitBounds(this.markersGroup.getBounds().pad(0.35));
      }
    }
  }

  focusDay(dayIndex, coords) {
    if (!this.map || !coords) return;
    this.map.flyTo(coords, 14, {
      animate: true,
      duration: 1.2
    });
  }
}

// Global instance
window.yatraMapInstance = new YatraMapController('itineraryMap');
