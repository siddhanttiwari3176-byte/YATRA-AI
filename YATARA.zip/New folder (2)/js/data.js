/**
 * YATRA AI - Core Dataset & Knowledge Base
 * SIH 2026 - Problem Statement SIH26204 (Student Innovation in Tourism Industries)
 */

const YATRA_DATA = {
  // Pre-configured dynamic destinations for AI Planner
  destinations: {
    "himachal": {
      name: "Kasol & Parvati Valley, Himachal Pradesh",
      tagline: "Alpine serenity, riverside cafes & student trekking havens",
      state: "Himachal Pradesh",
      vibe: "Mountain & Trekking",
      coords: [32.0100, 77.3150],
      baseCostPerDay: 1200,
      carbonPerDay: "12 kg CO₂e (Eco-Friendly)",
      highlights: ["Chalal riverside trail", "Manikaran hot springs", "Kheerganga natural sulfur pool", "Tosh village cafes"],
      studentTips: "HRTC ordinary buses from Bhuntar save 70% compared to private taxis. Carry your college ID for discounts at registered youth hostels.",
      days: [
        {
          day: 1,
          title: "Riverside Arrival & Chalal Forest Trail",
          coords: [32.0100, 77.3150],
          morning: {
            time: "09:00 AM - 12:30 PM",
            activity: "Arrival at Bhuntar, take local HRTC bus to Kasol. Check into riverside student backpacker hostel.",
            cost: "₹180 (Bus) + ₹450 (Dorm bed)",
            type: "Transit & Stay",
            studentPerk: "20% off with verified EduPass at Nomads Hostel"
          },
          afternoon: {
            time: "01:30 PM - 05:00 PM",
            activity: "Hike through pine forests to Chalal village. Try authentic trout and siddu at local Himachali family-run kitchen.",
            cost: "₹220 (Meal)",
            type: "Cultural Cuisine",
            studentPerk: "Free herbal tea with local community passport"
          },
          evening: {
            time: "06:30 PM - 09:30 PM",
            activity: "Acoustic jam session and stargazing by the Parvati riverbank. Plan group trek for next morning.",
            cost: "Free",
            type: "Social & Leisure",
            studentPerk: "Join shared bonfire circle"
          }
        },
        {
          day: 2,
          title: "Manikaran Sahib & Trek to Tosh Village",
          coords: [32.0170, 77.4500],
          morning: {
            time: "08:30 AM - 12:00 PM",
            activity: "Shared electric cab to Manikaran Sahib Gurudwara. Dip in therapeutic natural hot springs & Langar meal.",
            cost: "₹60 (Shared e-cab)",
            type: "Spiritual & Heritage",
            studentPerk: "Community Langar meal (Seva / Free)"
          },
          afternoon: {
            time: "01:00 PM - 05:30 PM",
            activity: "Trek up to scenic Tosh village at 2,400m altitude. Wooden Himachali architecture and apple orchards.",
            cost: "₹150 (Shared taxi from Barshaini)",
            type: "Adventure Hike",
            studentPerk: "Student group gear rental discount (30%)"
          },
          evening: {
            time: "06:30 PM - 09:30 PM",
            activity: "Sunset panoramic view of Shrikhand Mahadev peak. Local wood-fired pizza and mountain music.",
            cost: "₹250 (Dinner)",
            type: "Leisure",
            studentPerk: "Discounted board games & hot cocoa"
          }
        },
        {
          day: 3,
          title: "Kheerganga Trail or Malana Cultural Walk",
          coords: [31.9930, 77.5110],
          morning: {
            time: "07:30 AM - 01:00 PM",
            activity: "Ascend the misty waterfalls of Rudranag trail towards Kheerganga. Guided student group safety pod.",
            cost: "₹350 (Guide split)",
            type: "Trekking",
            studentPerk: "Free eco-waste bag provided (Clean Himalayas badge)"
          },
          afternoon: {
            time: "02:00 PM - 05:30 PM",
            activity: "Relax in top hot springs with 360-degree snow-capped Himalayas vista. Packed healthy student lunch.",
            cost: "₹180",
            type: "Wellness & Nature",
            studentPerk: "Eco-tourism discount on tent pitch"
          },
          evening: {
            time: "06:30 PM - 09:00 PM",
            activity: "Campfire astronomy and descend back / camp overnight under clear Milky Way sky.",
            cost: "₹400 (Shared tent)",
            type: "Night Adventure",
            studentPerk: "Free sleeping bag upgrade for student groups"
          }
        }
      ]
    },
    "hampi": {
      name: "Hampi & Anegundi, Karnataka",
      tagline: "UNESCO Vijayanagara ruins, boulder trails & tungsten sunsets",
      state: "Karnataka",
      vibe: "Heritage & History",
      coords: [15.3350, 76.4600],
      baseCostPerDay: 950,
      carbonPerDay: "9 kg CO₂e (Low-impact cycle transit)",
      highlights: ["Virupaksha Temple complex", "Matanga Hill sunrise", "Coracle boat ride on Tungabhadra", "Anegundi rural artisans"],
      studentTips: "Rent a bicycle for ₹100/day to explore ancient complexes. Carry your college ID for free or ₹25 entry tickets at ASI ticket counters.",
      days: [
        {
          day: 1,
          title: "Sacred Ruins & Matanga Hill Sunset",
          coords: [15.3350, 76.4600],
          morning: {
            time: "06:00 AM - 11:30 AM",
            activity: "Climb Matanga Hill for iconic golden hour sunrise over boulder kingdom. Visit 7th-century Virupaksha Temple.",
            cost: "₹50 (ASI pass with Student ID)",
            type: "Heritage & Trek",
            studentPerk: "50% discount on ASI monument passes"
          },
          afternoon: {
            time: "01:00 PM - 04:30 PM",
            activity: "Cycle through the Royal Enclosure, Hazara Rama temple bas-reliefs, and Lotus Mahal.",
            cost: "₹100 (Bicycle rental for full day)",
            type: "Eco Exploration",
            studentPerk: "Bicycle shared coupon via YATRA app"
          },
          evening: {
            time: "05:30 PM - 08:30 PM",
            activity: "Traditional South Indian Thali on banana leaf at Mango Tree cafe. Chill at Tungabhadra river steps.",
            cost: "₹160 (Unlimited Thali)",
            type: "Culinary Heritage",
            studentPerk: "Student loyalty beverage"
          }
        },
        {
          day: 2,
          title: "Vittala Musical Pillars & Coracle Crossings",
          coords: [15.3420, 76.4750],
          morning: {
            time: "08:30 AM - 12:30 PM",
            activity: "Audio-guided exploration of the iconic Stone Chariot and musical pillars at Vijaya Vittala Complex.",
            cost: "₹40 (Ticket) + ₹80 (Audio Guide)",
            type: "UNESCO Heritage",
            studentPerk: "Free audio guide QR on YATRA AI"
          },
          afternoon: {
            time: "01:30 PM - 05:00 PM",
            activity: "Cross Tungabhadra river via traditional round woven Coracle boat. Explore Hippie Island and Sanapur lake.",
            cost: "₹70 (Coracle ride shared)",
            type: "Local Transit & Adventure",
            studentPerk: "Group coracle discount"
          },
          evening: {
            time: "06:00 PM - 09:00 PM",
            activity: "Sunset bouldering with local certified climbers. Folk music showcase at local homestay.",
            cost: "₹200",
            type: "Culture & Sport",
            studentPerk: "Free crash-pad sharing for college squads"
          }
        },
        {
          day: 3,
          title: "Anegundi Ancient Heritage & Rural Artisans",
          coords: [15.3520, 76.4950],
          morning: {
            time: "08:00 AM - 12:00 PM",
            activity: "Visit the mythological Kishkindha (Anjaneya Hill) and historic water conservation channels of Vijayanagara.",
            cost: "Free",
            type: "Mythology & Nature",
            studentPerk: "Student historical map handout"
          },
          afternoon: {
            time: "01:00 PM - 04:30 PM",
            activity: "Banana fiber craft workshop at Anegundi Women's Artisan Guild. Learn indigenous weaving technique.",
            cost: "₹150 (Hands-on workshop fee)",
            type: "Vocal for Local",
            studentPerk: "Take home your handwoven souvenir"
          },
          evening: {
            time: "05:30 PM - 08:30 PM",
            activity: "Farewell rooftop dinner overlooking paddy fields and ancient stone towers. Board night train from Hospet.",
            cost: "₹200 (Dinner)",
            type: "Departure",
            studentPerk: "Student shared shuttle to Hospet Jn"
          }
        }
      ]
    },
    "varanasi": {
      name: "Varanasi (Kashi), Uttar Pradesh",
      tagline: "Eternal ghats, spiritual dawn, silk weavers & legendary street food",
      state: "Uttar Pradesh",
      vibe: "Spiritual Trails",
      coords: [25.3176, 82.9739],
      baseCostPerDay: 800,
      carbonPerDay: "8 kg CO₂e (Walking & Electric boat)",
      highlights: ["Subah-e-Banaras at Assi Ghat", "Ganga Aarti at Dashashwamedh", "Kachori Gali & Blue Lassi food walk", "Sarai Mohana silk weaving village"],
      studentTips: "Join the Subah-e-Banaras morning music program at Assi Ghat for free. Shared e-rickshaws anywhere along Godowlia cost only ₹15-20.",
      days: [
        {
          day: 1,
          title: "Subah-e-Banaras, Sacred Ghats & Evening Aarti",
          coords: [25.3176, 82.9739],
          morning: {
            time: "05:30 AM - 10:00 AM",
            activity: "Sunrise rowing boat from Assi Ghat to Manikarnika. Witness morning ragas, yoga on the ghat, and historic architecture.",
            cost: "₹120 (Shared student boat seat)",
            type: "Heritage & River",
            studentPerk: "Shared e-boat student pool via YATRA"
          },
          afternoon: {
            time: "11:30 AM - 04:00 PM",
            activity: "Street food pilgrimage: Ram Bhandar kachori sabzi, malyo (winter foam dessert), and world-famous Pahalwan lassi.",
            cost: "₹160 (Full food trail)",
            type: "Culinary Heritage",
            studentPerk: "Free food trail audio commentary"
          },
          evening: {
            time: "06:00 PM - 09:30 PM",
            activity: "Watch the world-famous Grand Maha Aarti at Dashashwamedh Ghat from steps. Night walk through ancient alleyways.",
            cost: "Free",
            type: "Spiritual Ceremony",
            studentPerk: "Priority student photography deck"
          }
        },
        {
          day: 2,
          title: "Sarnath Buddhist Trail & Banarasi Silk Weavers",
          coords: [25.3811, 83.0214],
          morning: {
            time: "08:30 AM - 01:00 PM",
            activity: "E-rickshaw to Sarnath where Buddha delivered his first sermon. Dhamek Stupa and Sarnath ASI Archeological Museum.",
            cost: "₹25 (Student Museum pass) + ₹40 (E-rickshaw)",
            type: "UNESCO Buddhist Trail",
            studentPerk: "Zero entry fee for students with ID on select days"
          },
          afternoon: {
            time: "02:00 PM - 05:30 PM",
            activity: "Visit Sarai Mohana village. Witness Master Weaver families crafting authentic Zari Banarasi sarees on handlooms.",
            cost: "Free / Community tip",
            type: "Vocal for Local",
            studentPerk: "Direct artisan pricing on fabric souvenirs"
          },
          evening: {
            time: "06:30 PM - 09:00 PM",
            activity: "Rooftop classical sitar and tabla performance at Assi Ghat cultural center with masala chai.",
            cost: "₹150",
            type: "Performing Arts",
            studentPerk: "Student entry concession"
          }
        }
      ]
    },
    "rishikesh": {
      name: "Rishikesh & Shivpuri, Uttarakhand",
      tagline: "Yoga capital of the world, white water rapids & Himalayan cliff cafes",
      state: "Uttarakhand",
      vibe: "Adventure Trek",
      coords: [30.0869, 78.2676],
      baseCostPerDay: 1100,
      carbonPerDay: "11 kg CO₂e (Eco-friendly shared jeeps)",
      highlights: ["16km White Water Rafting", "Beatles Ashram graffiti walk", "Triveni Ghat Evening Aarti", "Neer Garh waterfall hike"],
      studentTips: "Book rafting directly with certified Uttarakhand Tourism (UTDB) operators in groups of 8 to get flat student rates of ₹650 per person.",
      days: [
        {
          day: 1,
          title: "White Water Rafting & Cliff Jumping",
          coords: [30.0869, 78.2676],
          morning: {
            time: "08:30 AM - 01:30 PM",
            activity: "16 km thrilling Grade III/IV white water rafting from Shivpuri to NIM Beach with cliff jumping and body surfing.",
            cost: "₹650 (Group student rate)",
            type: "Adventure Sports",
            studentPerk: "Free GoPro action video split"
          },
          afternoon: {
            time: "02:30 PM - 05:30 PM",
            activity: "Hike to Neer Garh multi-tier waterfall. Cool dip in natural stone pools followed by Maggi and chai.",
            cost: "₹30 (Entry fee)",
            type: "Eco Trek",
            studentPerk: "Free entry for students with college ID"
          },
          evening: {
            time: "06:30 PM - 09:00 PM",
            activity: "Spiritual Ganga Aarti at Triveni Ghat with oil lamps floating on the holy river. Chanting and live bell chimes.",
            cost: "Free",
            type: "Spiritual & Community",
            studentPerk: "Open seating"
          }
        },
        {
          day: 2,
          title: "Beatles Ashram & Tapovan Cafe Culture",
          coords: [30.1158, 78.3180],
          morning: {
            time: "09:00 AM - 01:00 PM",
            activity: "Explore the Beatles Ashram (Chaurasi Kutia) in Rajaji Tiger Reserve. Marvel at psychedelic murals and meditation domes.",
            cost: "₹75 (Student concession pass)",
            type: "Heritage & Art",
            studentPerk: "50% discount on forest entry ticket"
          },
          afternoon: {
            time: "02:00 PM - 05:30 PM",
            activity: "Cafe hopping in Tapovan: Try vegan thali, woodfired pizza, and smoothie bowls overlooking Lakshman Jhula.",
            cost: "₹250",
            type: "Student Hangout",
            studentPerk: "15% off food bill with EduPass"
          },
          evening: {
            time: "06:30 PM - 09:30 PM",
            activity: "Riverside acoustic guitar circle and beach camping setup on pristine white sand Ganga bank.",
            cost: "₹450 (Riverside tent stay)",
            type: "Camping",
            studentPerk: "Shared campfire wood & stargazing telescope"
          }
        }
      ]
    },
    "meghalaya": {
      name: "Shillong, Cherrapunji & Mawlynnong, Meghalaya",
      tagline: "Living root bridges, crystal rivers, misty waterfalls & matrilineal culture",
      state: "Meghalaya",
      vibe: "Eco-Tourism",
      coords: [25.5788, 91.8933],
      baseCostPerDay: 1350,
      carbonPerDay: "10 kg CO₂e (Carbon-neutral community homestays)",
      highlights: ["Double Decker Living Root Bridge", "Umngot River transparent boats at Dawki", "Mawlynnong Asia's Cleanest Village", "Nohkalikai Waterfall"],
      studentTips: "Shared sumo cabs from Police Bazar in Shillong to Cherrapunji cost only ₹120. Stay in community-run Khasi homestays.",
      days: [
        {
          day: 1,
          title: "Misty Waterfalls & Khasi Heritage in Sohra",
          coords: [25.2744, 91.7323],
          morning: {
            time: "08:00 AM - 12:30 PM",
            activity: "Shared cab to Sohra (Cherrapunji). Gaze at India's tallest plunge waterfall Nohkalikai & explore Mawsmai limestone cave.",
            cost: "₹120 (Transit) + ₹50 (Cave pass)",
            type: "Geological Wonder",
            studentPerk: "Eco-Tourism student card concession"
          },
          afternoon: {
            time: "01:30 PM - 05:00 PM",
            activity: "Hike down the 3,000 stone stairs to Nongriat to marvel at the 250-year-old Double Decker Living Root Bridge.",
            cost: "₹100 (Community maintenance fee)",
            type: "Indigenous Engineering",
            studentPerk: "Free bamboo trekking pole rental"
          },
          evening: {
            time: "06:00 PM - 09:00 PM",
            activity: "Overnight in Nongriat village homestay. Enjoy warm Khasi home-cooked stew and listening to tribal folklore.",
            cost: "₹400 (Homestay bed & dinner)",
            type: "Community Homestay",
            studentPerk: "Direct contribution to tribal self-help fund"
          }
        },
        {
          day: 2,
          title: "Dawki Crystal Waters & Cleanest Village Mawlynnong",
          coords: [25.1880, 92.0234],
          morning: {
            time: "08:00 AM - 12:30 PM",
            activity: "Head to Dawki border. Row on the unreal glass-like waters of Umngot River where boats appear to float in mid-air.",
            cost: "₹250 (Shared boat ride)",
            type: "Eco Water Trail",
            studentPerk: "YATRA pooled student boat"
          },
          afternoon: {
            time: "01:30 PM - 05:30 PM",
            activity: "Walk through Mawlynnong, recognized as Asia's Cleanest Village. Discover zero-waste bamboo dustbins and treehouses.",
            cost: "₹50",
            type: "Sustainability Model",
            studentPerk: "Student environmental workshop certificate"
          },
          evening: {
            time: "06:30 PM - 09:30 PM",
            activity: "Return to Shillong Police Bazar. Indie rock live performance at Dylan's Cafe with steamed pork/veg momos.",
            cost: "₹220",
            type: "Culture & Music",
            studentPerk: "10% music gig discount for college students"
          }
        }
      ]
    },
    "gokarna": {
      name: "Gokarna & Honnavar, Karnataka",
      tagline: "Pristine cliffside beach treks, Arabian sunset cafes & quiet temple lanes",
      state: "Karnataka",
      vibe: "Coastal & Relax",
      coords: [14.5479, 74.3188],
      baseCostPerDay: 900,
      carbonPerDay: "7 kg CO₂e (Walking coastal trails)",
      highlights: ["Five Beach Trek (Kudle, Om, Half Moon, Paradise)", "Honnavar mangrove boat safari", "Mahabaleshwar Temple", "Cliffside hammock cafes"],
      studentTips: "Trek between beaches on foot rather than taking expensive autos. Om Beach to Paradise Beach is a stunning 2-hour coastal walk.",
      days: [
        {
          day: 1,
          title: "The Legendary 5-Beach Cliff Trek",
          coords: [14.5479, 74.3188],
          morning: {
            time: "07:00 AM - 12:30 PM",
            activity: "Start from Gokarna Main Beach, traverse cliffs through Kudle Beach to the sacred Om-shaped coastline.",
            cost: "Free (Hiking trail)",
            type: "Coastal Trekking",
            studentPerk: "Download offline GPS trail map on YATRA"
          },
          afternoon: {
            time: "01:00 PM - 04:30 PM",
            activity: "Trek through rugged rocks to secluded Half Moon Beach and Paradise Beach. Swim in calm turquoise coves.",
            cost: "₹180 (Fresh coconut & shack lunch)",
            type: "Nature & Beach",
            studentPerk: "Student group safety beacon sync"
          },
          evening: {
            time: "05:30 PM - 09:00 PM",
            activity: "Sunset drum circle and fire spinning at Kudle Beach. Fresh woodfired seafood/falafel platter.",
            cost: "₹240 (Dinner)",
            type: "Bohemian Sunset",
            studentPerk: "Free beach yoga mat rental"
          }
        },
        {
          day: 2,
          title: "Honnavar Mangrove Safari & Bioluminescence",
          coords: [14.2810, 74.4439],
          morning: {
            time: "08:30 AM - 01:00 PM",
            activity: "Shared local passenger train to Honnavar (₹20). Kayak or eco-boat through serene Sharavati river backwaters.",
            cost: "₹20 (Train) + ₹200 (Boat safari)",
            type: "Eco Waterway",
            studentPerk: "Student group kayak discount (25%)"
          },
          afternoon: {
            time: "02:00 PM - 05:30 PM",
            activity: "Explore 4th-century Mahabaleshwar Temple with Atmalinga shrine. Taste authentic Karavali curries.",
            cost: "₹120 (Traditional meal)",
            type: "Spiritual & Heritage",
            studentPerk: "Free temple heritage walkthrough"
          },
          evening: {
            time: "07:00 PM - 10:00 PM",
            activity: "Night walk along Nirvana beach to spot glowing blue marine bioluminescence in sea waves (seasonal).",
            cost: "Free",
            type: "Night Phenomenon",
            studentPerk: "Night safety buddy tracker enabled"
          }
        }
      ]
    }
  },

  // Cultural Hidden Gems & Vocal for Local Artisans
  culturalHub: [
    {
      id: "gem-1",
      name: "Channapatna Wooden Toy Village",
      location: "Ramanagara District, Karnataka",
      category: "Indigenous Artisans",
      badge: "GI Tagged Heritage",
      image: "https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?auto=format&fit=crop&w=700&q=80",
      description: "Home to 3,000+ artisans turning sustainable ivory wood into non-toxic lacquered toys using natural vegetable dyes since Tipu Sultan's era.",
      studentImpact: "Direct artisan workshop bookings eliminate middle-men, ensuring 85% revenue goes directly into artisan women's bank accounts.",
      price: "₹150 for 1-hr live lathe craft workshop",
      contact: "Artisan Co-Op: +91 80 2725 4321"
    },
    {
      id: "gem-2",
      name: "Majuli Island Mask Making & Satras",
      location: "Brahmaputra River, Assam",
      category: "Folk Arts",
      badge: "World's Largest River Island",
      image: "https://images.unsplash.com/photo-1609137144813-7d9921338f24?auto=format&fit=crop&w=700&q=80",
      description: "Ancient Vaishnavite monasteries where monks sculpt biodegradable bamboo and cow dung theatrical masks used in 500-year-old Bhaona dances.",
      studentImpact: "Students stay at monastery guest huts for ₹300/night and help digitize ancient Assamese palm-leaf manuscripts.",
      price: "₹300/night community stay",
      contact: "Samaguri Satra: +91 9435 092 114"
    },
    {
      id: "gem-3",
      name: "Chettinad 1,000-Window Heritage Mansions",
      location: "Sivaganga District, Tamil Nadu",
      category: "Hidden Heritage",
      badge: "Architectural Marvel",
      image: "https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=700&q=80",
      description: "Magnificent 19th-century merchant mansions built with Burmese teak, Italian marble, and Belgian mirrors alongside Athangudi handmade tiles.",
      studentImpact: "Architecture and design students receive free entry for sketch study tours by coordinating with the local heritage preservation trust.",
      price: "₹50 entry / Free for Architecture IDs",
      contact: "Chettinad Heritage Trust: +91 4565 241 002"
    },
    {
      id: "gem-4",
      name: "Lonar Geothermal Meteorite Crater Lake",
      location: "Buldhana District, Maharashtra",
      category: "Hidden Heritage",
      badge: "Ramsar Eco-Site",
      image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=700&q=80",
      description: "The world's only hyper-velocity impact crater formed 50,000 years ago in basalt rock, harboring both saline and alkaline distinct microbial zones.",
      studentImpact: "Geology and biology students guide weekend backpacker walking groups to fund local school lake preservation clubs.",
      price: "Free public access with eco-pledge",
      contact: "Forest Range Office: 07260-221245"
    },
    {
      id: "gem-5",
      name: "Old Delhi Spice & Street Food Walk",
      location: "Chandni Chowk & Khari Baoli, Delhi",
      category: "Street Food Walks",
      badge: "Asia's Largest Spice Market",
      image: "https://images.unsplash.com/photo-1596797038530-2c107229654b?auto=format&fit=crop&w=700&q=80",
      description: "Wander through 400-year-old spice lanes of Khari Baoli, savor historic Paranthe Wali Gali flatbreads, and sample Daulat ki Chaat.",
      studentImpact: "Student food ambassadors guide budget foodies through heritage alleys, keeping costs strictly under ₹250 per bellyful.",
      price: "₹200 average food tasting budget",
      contact: "Delhi Heritage Walk: +91 11 2327 9800"
    },
    {
      id: "gem-6",
      name: "Blue Pottery & Clay Masters of Kot Jewar",
      location: "Jaipur Rural, Rajasthan",
      category: "Indigenous Artisans",
      badge: "Vocal for Local",
      image: "https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=700&q=80",
      description: "Traditional Rajasthani turquoise glazed ceramic craft that uses no clay—made entirely from quartz powder, raw glass, and gum.",
      studentImpact: "Student-run direct marketplace connect artisans directly to pan-India youth hostel decor projects without middlemen cuts.",
      price: "₹250 for ceramic painting session",
      contact: "Kripal Kumbh Rural Guild: +91 141 220 1127"
    }
  ],

  // Multilingual Student Phrasebook
  phrasebook: {
    "hi": {
      name: "Hindi (हिन्दी)",
      greeting: "नमस्ते (Namaste)",
      phrases: [
        { en: "How much does this cost?", native: "यह कितने का है?", roman: "Yeh kitne ka hai?", tip: "Always polite for asking prices in markets and autos." },
        { en: "Is there a student discount?", native: "क्या यहाँ छात्रों के लिए छूट है?", roman: "Kya yahan chhaatron ke liye chhoot hai?", tip: "Show your college ID card immediately." },
        { en: "Where is the nearest bus station?", native: "नज़दीकी बस स्टैंड कहाँ है?", roman: "Nazdeeki bus stand kahan hai?", tip: "Locals are very helpful with bus routes." },
        { en: "Please make the food less spicy.", native: "कृपया खाना कम तीखा बनाएं।", roman: "Kripya khana kam teekha banayein.", tip: "Essential for street food carts." },
        { en: "Please help, I need emergency assistance.", native: "कृपया मदद करें, मुझे आपातकालीन सहायता चाहिए।", roman: "Kripya madad karein, mujhe aapatkaleen sahayata chahiye.", tip: "Dial 112 or 1363 for tourism police." }
      ]
    },
    "ta": {
      name: "Tamil (தமிழ்)",
      greeting: "வணக்கம் (Vanakkam)",
      phrases: [
        { en: "How much does this cost?", native: "இது என்ன விலை?", roman: "Idhu enna vilai?", tip: "Use at bus stands and tea stalls." },
        { en: "Is there a student discount?", native: "மாணவர்களுக்கு தள்ளுபடி உண்டா?", roman: "Maanavargalukku thallupadi undaa?", tip: "State express buses have concessions." },
        { en: "Where is the bus stop?", native: "பேருந்து நிறுத்தம் எங்கே?", roman: "Perundhu niruttham engey?", tip: "Look for government bus shelters." },
        { en: "One cup of filter coffee, please.", native: "ஒரு கப் ஃபில்டர் காபி கொடுங்க.", roman: "Oru cup filter coffee kodunga.", tip: "The soul of South Indian travel." },
        { en: "Please help me.", native: "தயவுசெய்து எனக்கு உதவுங்கள்.", roman: "Dayavu seidhu enakku udhavungal.", tip: "Emergency support phrase." }
      ]
    },
    "bn": {
      name: "Bengali (বাংলা)",
      greeting: "নমস্কার (Nomoshkar)",
      phrases: [
        { en: "How much does this cost?", native: "এটার দাম কত?", roman: "Etar daam koto?", tip: "Perfect for Kolkata trams and street markets." },
        { en: "Is there a student discount?", native: "ছাত্রদের জন্য কোনো ছাড় আছে কি?", roman: "Chhatroder jonyo kono chhar aachhe ki?", tip: "Valid for museum and tram passes." },
        { en: "Where can I get good local food?", native: "ভালো স্থানীয় খাবার কোথায় পাওয়া যাবে?", roman: "Bhalo sthaniya khabar kothay pawa jabe?", tip: "Ask for authentic mishti & fish curry." },
        { en: "Which way goes to the railway station?", native: "স্টেশনে কোন পথ দিয়ে যায়?", roman: "Station-e kon poth diye jaay?", tip: "Direction inquiry." },
        { en: "Please help me.", native: "আমাকে একটু সাহায্য করুন।", roman: "Amake ektu sahajjo korun.", tip: "Emergency request." }
      ]
    },
    "mr": {
      name: "Marathi (मराठी)",
      greeting: "नमस्कार (Namaskar)",
      phrases: [
        { en: "How much does this cost?", native: "हे किती रुपयांना आहे?", roman: "He kiti rupayanna aahe?", tip: "Used across Maharashtra forts & Pune markets." },
        { en: "Is there a student discount?", native: "विद्यार्थ्यांसाठी काही सवलत आहे का?", roman: "Vidyarthyaansathi kahi savlat aahe ka?", tip: "Show college ID for ST bus & fort passes." },
        { en: "Where does this bus go?", native: "ही बस कुठे जाते?", roman: "Hee bus kuthe jaate?", tip: "Check red MSRTC buses." },
        { en: "Give one hot Vada Pav, please.", native: "एक गरम वडा पाव द्या ना.", roman: "Ek garam vada pav dya na.", tip: "The ultimate student budget meal (₹15)." },
        { en: "Please help me urgently.", native: "कृपया मला तातडीने मदत करा.", roman: "Krupaya mala taatadineey madad kara.", tip: "Emergency phrase." }
      ]
    },
    "gu": {
      name: "Gujarati (ગુજરાતી)",
      greeting: "નમસ્તે (Kem Cho / Namaste)",
      phrases: [
        { en: "How much does this cost?", native: "આ કેટલા રૂપિયાનું છે?", roman: "Aa ketla rupiya nu chhe?", tip: "Standard market inquiry." },
        { en: "Is there a student discount?", native: "વિદ્યાર્થીઓ માટે કોઈ ડિસ્કાઉન્ટ છે?", roman: "Vidyarthio maate koi discount chhe?", tip: "Ask at heritage stepwells & museums." },
        { en: "Where is the best Gujarati Thali?", native: "સૌથી સારી ગુજરાતી થાળી ક્યાં મળશે?", roman: "Sauthi saari Gujarati thali kyan malshe?", tip: "Unlimited student feasts!" },
        { en: "Please show me the road.", native: "મને રસ્તો બતાવો ને.", roman: "Mane rasto bataavo ne.", tip: "Friendly direction inquiry." },
        { en: "I need assistance.", native: "મને મદદની જરૂર છે.", roman: "Mane madad ni jaroor chhe.", tip: "Emergency assistance." }
      ]
    }
  },

  // Student Travel Pool / Buddy Finder Initial Mock Feed
  initialBuddyPools: [
    {
      id: "pool-101",
      creatorName: "Aryan Sharma",
      college: "IIT Delhi (Batch '26)",
      destination: "Kasol & Kheerganga Trek",
      dateRange: "Oct 12 - Oct 15",
      type: "Trekking Squad",
      seatsTotal: 5,
      seatsLeft: 2,
      costEstimate: "₹850 / person for private tempo traveler from Majnu Ka Tilla",
      genderPref: "Open to All Students",
      verified: true,
      description: "Booked a clean 12-seater tempo from Delhi to Kasol. We are 3 computer science students, looking for 2 fellow students to split the travel cost and share a Kheerganga tent!"
    },
    {
      id: "pool-102",
      creatorName: "Ananya Iyer & Riya Sen",
      college: "St. Xavier's Mumbai",
      destination: "Gokarna Cliff & Beach Camping",
      dateRange: "Nov 02 - Nov 05",
      type: "Girls-Only Safe Pool",
      seatsTotal: 4,
      seatsLeft: 2,
      costEstimate: "₹650 / person for shared beach cottage & cab",
      genderPref: "Female Students Only",
      verified: true,
      description: "Planning a peaceful workation/trip to Gokarna for beach walks, cafe hopping and pottery. Looking for 2 female college buddies to share safety-verified accommodation."
    },
    {
      id: "pool-103",
      creatorName: "Tanmay Deshmukh",
      college: "COEP Pune",
      destination: "Hampi Bicycle & Architecture Expedition",
      dateRange: "Oct 24 - Oct 27",
      type: "College Squad",
      seatsTotal: 6,
      seatsLeft: 3,
      costEstimate: "₹500 / day covering rented mopeds & homestay split",
      genderPref: "Open to All Students",
      verified: true,
      description: "Exploring Hampi ruins on mopeds and coracle boats. We love photography, bouldering, and historical architecture. Low-budget hostel booking already locked in Hospet!"
    },
    {
      id: "pool-104",
      creatorName: "Pooja Verma",
      college: "BHU Varanasi",
      destination: "Varanasi Dawn Boat & Street Food Pod",
      dateRange: "Every Weekend",
      type: "Local Guide Pod",
      seatsTotal: 8,
      seatsLeft: 4,
      costEstimate: "₹120 / student for private e-boat sunrise tour",
      genderPref: "Open to All Students",
      verified: true,
      description: "We are local BHU tourism student ambassadors. Join our sunrise boat group from Assi to Manikarnika Ghat with free student historical commentary and kachori breakfast!"
    }
  ],

  // Chatbot Q&A Knowledge Triggers
  chatKnowledge: [
    {
      keywords: ["sos", "emergency", "police", "help", "helpline", "danger", "safe"],
      response: `🚨 **OFFICIAL 24x7 TOURIST HELPLINES IN INDIA:**\n\n• **National Tourism Helpline**: **1363** (Toll-Free, 12 languages supported)\n• **Unified Emergency Services**: **112** (Police, Fire, Ambulance)\n• **Women Helpline**: **1091** or **181**\n• **Railway Protection Force (RPF)**: **139** (For assistance on trains/stations)\n\n📍 *YATRA Safety Tip: Share your live location with your designated buddy pool before setting off on remote hikes.*`
    },
    {
      keywords: ["discount", "edupass", "id card", "student card", "asi", "cheap"],
      response: `🎓 **TOP STUDENT TRAVEL DISCOUNTS IN BHARAT:**\n\n1. **ASI Heritage Monuments**: Under ASI guidelines, Indian school/college students often receive free entry or tickets at just **₹25** (vs ₹500 for foreign tourists / full adult fare). Keep your College ID handy!\n2. **IRCTC Student Concession**: 50% concession in Second/Sleeper class for traveling between hometown and educational institution (requires signed form from your principal).\n3. **Hostels & Stays**: Chains like The Hosteller, Zostel, and goSTOPS provide **10-20% off** student rates when booked via YATRA EduPass integration.\n4. **Air Travel**: Air India & IndiGo offer **up to 25% base fare discount** + 25kg extra baggage allowance for verified students.`
    },
    {
      keywords: ["budget", "himachal", "spiti", "kasol", "manali"],
      response: `🏔️ **POCKET-FRIENDLY HIMACHAL STUDENT BLUEPRINT (₹3,500 - ₹5,000 for 4 Days):**\n\n• **Transit**: Take Delhi/Chandigarh to Bhuntar via HRTC ordinary state bus (~₹650) instead of private Volvos (~₹1,500).\n• **Stay**: Backpacker dorm beds in Kasol/Old Manali cost ₹350 - ₹500/night.\n• **Food**: Savor local Siddu, Thukpa, and Dhaba thalis for ₹120 - ₹180.\n• **Trek**: Kheerganga or Bijli Mahadev can be done self-guided without paying ₹2,000 agency fees if you join a YATRA student buddy pool!`
    },
    {
      keywords: ["hampi", "ruins", "cycle", "karnataka"],
      response: `🏛️ **HAMPI ON A SHOESTRING (Under ₹900/day):**\n\n• Rent a geared bicycle near Virupaksha temple for **₹100/day**.\n• Stay across the river in Sanapur/Anegundi or near Hospet station for budget dorms (₹400/night).\n• Don't miss the free sunrise at Matanga Hill and golden hour sunset at Hemakuta Hill!\n• Food: Banana leaf South Indian meals at local messes for ₹80-₹120 unlimited.`
    },
    {
      keywords: ["varanasi", "kashi", "boat", "ghat", "food"],
      response: `🪔 **VARANASI EXPERIENCES NOT TO MISS:**\n\n• **Morning**: 5:30 AM Subah-e-Banaras at Assi Ghat (Free classical music & yoga).\n• **Boat Ride**: Take a shared rowing or e-boat (₹100-₹150/head). Never pay more than ₹300 individually!\n• **Food Crawl**: Ram Bhandar kachori at 8 AM, Blue Lassi shop, and Tamatar Chaat at Kashi Chaat Bhandar.\n• **Evening**: Arrive at Dashashwamedh Ghat by 6:00 PM for front-row view of the Ganga Aarti.`
    }
  ]
};
