/**
 * YATRA AI - Dynamic AI Itinerary & Tour Planner Engine
 * Handles custom parameter generation, simulated AI reasoning pipeline,
 * and day-by-day interactive timeline synthesis.
 */

const YatraPlanner = {
  activeDestinationKey: 'himachal',
  activeDaysCount: 3,

  init() {
    const form = document.getElementById('plannerForm');
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleGenerate();
      });
    }

    // Set initial quick chips
    document.querySelectorAll('.dest-quick-chip').forEach(chip => {
      chip.addEventListener('click', (e) => {
        const destKey = e.currentTarget.dataset.dest;
        this.selectAndGenerate(destKey);
      });
    });

    // Duration slider live update
    const durationInput = document.getElementById('planDuration');
    const durationVal = document.getElementById('durationVal');
    if (durationInput && durationVal) {
      durationInput.addEventListener('input', (e) => {
        durationVal.textContent = `${e.target.value} ${e.target.value === '1' ? 'Day' : 'Days'}`;
      });
    }
  },

  selectAndGenerate(destKey) {
    const destSelect = document.getElementById('planDestination');
    if (destSelect) {
      destSelect.value = destKey;
    }
    // Scroll to planner section smoothly
    const plannerSec = document.getElementById('planner');
    if (plannerSec) {
      plannerSec.scrollIntoView({ behavior: 'smooth' });
    }
    this.handleGenerate();
  },

  handleGenerate() {
    const destKey = document.getElementById('planDestination')?.value || 'himachal';
    const days = parseInt(document.getElementById('planDuration')?.value || '3', 10);
    const budgetTier = document.getElementById('planBudget')?.value || 'budget';
    const vibe = document.getElementById('planVibe')?.value || 'adventure';
    const group = document.getElementById('planGroup')?.value || 'solo';

    this.activeDestinationKey = destKey;
    this.activeDaysCount = days;

    const loadingElem = document.getElementById('plannerLoading');
    const outputElem = document.getElementById('plannerOutput');
    const emptyElem = document.getElementById('plannerEmpty');

    if (emptyElem) emptyElem.classList.add('hidden');
    if (outputElem) outputElem.classList.add('hidden');
    if (loadingElem) loadingElem.classList.remove('hidden');

    // Simulated AI Reasoning Pipeline sequence
    const statusText = document.getElementById('aiStatusStep');
    const steps = [
      "Analyzing student travel routes & HRTC/train connectivity...",
      "Querying verified student hostels & homestays...",
      "Computing ASI heritage monuments & student concessions...",
      "Calculating carbon-neutral transit scores...",
      "Generating day-by-day smart schedule & map waypoints..."
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      currentStep++;
      if (currentStep < steps.length && statusText) {
        statusText.textContent = steps[currentStep];
      } else {
        clearInterval(interval);
        if (loadingElem) loadingElem.classList.add('hidden');
        if (outputElem) outputElem.classList.remove('hidden');
        this.renderItinerary(destKey, days, budgetTier, vibe, group);
      }
    }, 450);
  },

  renderItinerary(destKey, days, budgetTier, vibe, group) {
    const dest = YATRA_DATA.destinations[destKey] || YATRA_DATA.destinations['himachal'];
    const timelineContainer = document.getElementById('timelineSchedule');
    const summaryContainer = document.getElementById('itineraryHeaderSummary');

    // Budget multiplier adjustments
    let multiplier = 1.0;
    let tierName = "Student Shoestring";
    if (budgetTier === 'backpacker') {
      multiplier = 1.35;
      tierName = "Backpacker Explorer";
    } else if (budgetTier === 'comfort') {
      multiplier = 1.85;
      tierName = "Comfort Explorer";
    }

    // Group discounts
    let groupSavings = "Individual";
    let groupFactor = 1.0;
    if (group === 'duo') {
      groupFactor = 0.9;
      groupSavings = "10% shared room savings";
    } else if (group === 'squad') {
      groupFactor = 0.78;
      groupSavings = "22% group cab & stay discount";
    }

    const estimatedTotalPerStudent = Math.round(dest.baseCostPerDay * days * multiplier * groupFactor);
    const savingsAmount = Math.round(estimatedTotalPerStudent * 0.28);

    // Update Header Summary
    if (summaryContainer) {
      summaryContainer.innerHTML = `
        <div class="bg-gradient-to-r from-slate-900 to-teal-950 text-white p-6 rounded-2xl shadow-xl mb-6 relative overflow-hidden">
          <div class="absolute right-0 top-0 translate-x-4 -translate-y-4 w-44 h-44 bg-orange-500/10 rounded-full blur-2xl"></div>
          
          <div class="flex flex-wrap items-center justify-between gap-4 mb-3">
            <div>
              <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-orange-500/20 text-orange-400 border border-orange-500/30">
                <i class="fas fa-sparkles"></i> AI Generated Itinerary • ${dest.vibe}
              </span>
              <h3 class="text-2xl lg:text-3xl font-bold mt-2 text-white">${dest.name}</h3>
              <p class="text-slate-300 text-sm mt-1 max-w-2xl">${dest.tagline}</p>
            </div>
            
            <div class="text-right bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/15">
              <div class="text-xs uppercase tracking-wider text-slate-300 font-medium">Estimated Per Student</div>
              <div class="text-3xl font-extrabold text-orange-400">₹${estimatedTotalPerStudent.toLocaleString('en-IN')}</div>
              <div class="text-[11px] text-teal-300 mt-0.5">Save approx. ₹${savingsAmount} with EduPass</div>
            </div>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-white/10 text-xs">
            <div class="flex items-center gap-2">
              <span class="p-2 bg-white/10 rounded-lg text-orange-400"><i class="fas fa-calendar-day"></i></span>
              <div>
                <p class="text-slate-400">Duration</p>
                <p class="font-bold text-white">${days} ${days === 1 ? 'Day' : 'Days'}</p>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <span class="p-2 bg-white/10 rounded-lg text-teal-400"><i class="fas fa-wallet"></i></span>
              <div>
                <p class="text-slate-400">Tier & Group</p>
                <p class="font-bold text-white">${tierName} (${groupSavings})</p>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <span class="p-2 bg-white/10 rounded-lg text-emerald-400"><i class="fas fa-leaf"></i></span>
              <div>
                <p class="text-slate-400">Eco-Score</p>
                <p class="font-bold text-emerald-300">${dest.carbonPerDay}</p>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <span class="p-2 bg-white/10 rounded-lg text-amber-400"><i class="fas fa-id-card"></i></span>
              <div>
                <p class="text-slate-400">Student Status</p>
                <p class="font-bold text-amber-300">Verified Concessions Active</p>
              </div>
            </div>
          </div>

          <div class="mt-4 p-3 bg-orange-500/15 border border-orange-500/30 rounded-xl text-xs text-orange-200 flex items-center gap-2">
            <i class="fas fa-lightbulb text-orange-400 text-sm"></i>
            <span><strong>Smart Travel Tip:</strong> ${dest.studentTips}</span>
          </div>
        </div>
      `;
    }

    // Render Timeline Days
    if (timelineContainer) {
      timelineContainer.innerHTML = '';
      const availableDays = dest.days.slice(0, days);

      availableDays.forEach((dayData, index) => {
        const dayNum = index + 1;
        const dayCard = document.createElement('div');
        dayCard.className = 'relative pl-8 pb-8 border-l-2 border-orange-200 last:border-transparent group';

        dayCard.innerHTML = `
          <!-- Day Marker Pin -->
          <div class="absolute -left-[17px] top-0 w-8 h-8 rounded-full bg-gradient-to-br from-orange-500 to-amber-500 text-white font-bold flex items-center justify-center text-xs shadow-md group-hover:scale-110 transition-transform">
            ${dayNum}
          </div>

          <div class="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
            <div class="flex flex-wrap items-center justify-between gap-2 mb-3">
              <h4 class="text-lg font-bold text-slate-900">Day ${dayNum}: ${dayData.title}</h4>
              <button onclick="window.yatraMapInstance.focusDay(${index}, [${dayData.coords.join(',')}])" 
                class="inline-flex items-center gap-1 text-xs font-semibold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-lg hover:bg-teal-100 transition-colors">
                <i class="fas fa-map-marker-alt"></i> View on Map
              </button>
            </div>

            <!-- Time Slots -->
            <div class="space-y-3 text-sm">
              <!-- Morning -->
              <div class="p-3.5 rounded-xl bg-orange-50/50 border border-orange-100/80">
                <div class="flex items-center justify-between text-xs font-semibold text-orange-700 mb-1">
                  <span class="flex items-center gap-1.5"><i class="fas fa-sun text-amber-500"></i> Morning • ${dayData.morning.time}</span>
                  <span class="bg-white px-2 py-0.5 rounded shadow-2xs font-bold text-slate-700">${dayData.morning.cost}</span>
                </div>
                <p class="text-slate-800 text-xs leading-relaxed">${dayData.morning.activity}</p>
                <div class="mt-2 text-[11px] text-teal-800 font-medium flex items-center gap-1">
                  <i class="fas fa-tag text-teal-600"></i> ${dayData.morning.studentPerk}
                </div>
              </div>

              <!-- Afternoon -->
              <div class="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70">
                <div class="flex items-center justify-between text-xs font-semibold text-slate-700 mb-1">
                  <span class="flex items-center gap-1.5"><i class="fas fa-cloud-sun text-orange-500"></i> Afternoon • ${dayData.afternoon.time}</span>
                  <span class="bg-white px-2 py-0.5 rounded shadow-2xs font-bold text-slate-700">${dayData.afternoon.cost}</span>
                </div>
                <p class="text-slate-800 text-xs leading-relaxed">${dayData.afternoon.activity}</p>
                <div class="mt-2 text-[11px] text-teal-800 font-medium flex items-center gap-1">
                  <i class="fas fa-tag text-teal-600"></i> ${dayData.afternoon.studentPerk}
                </div>
              </div>

              <!-- Evening -->
              <div class="p-3.5 rounded-xl bg-slate-900 text-white">
                <div class="flex items-center justify-between text-xs font-semibold text-orange-400 mb-1">
                  <span class="flex items-center gap-1.5"><i class="fas fa-moon text-amber-300"></i> Evening • ${dayData.evening.time}</span>
                  <span class="bg-white/15 px-2 py-0.5 rounded font-bold text-white">${dayData.evening.cost}</span>
                </div>
                <p class="text-slate-300 text-xs leading-relaxed">${dayData.evening.activity}</p>
                <div class="mt-2 text-[11px] text-teal-300 font-medium flex items-center gap-1">
                  <i class="fas fa-star text-amber-400"></i> ${dayData.evening.studentPerk}
                </div>
              </div>
            </div>
          </div>
        `;

        timelineContainer.appendChild(dayCard);
      });
    }

    // Trigger Leaflet Map updates
    if (window.yatraMapInstance) {
      window.yatraMapInstance.renderDestinationItinerary(destKey, days);
    }
  },

  printItinerary() {
    window.print();
  },

  shareItinerary() {
    const url = window.location.href;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(url).then(() => {
        if (window.YatraApp && window.YatraApp.showToast) {
          window.YatraApp.showToast("Trip itinerary link copied to clipboard!", "success");
        } else {
          alert("Trip itinerary link copied to clipboard!");
        }
      });
    }
  }
};

window.YatraPlanner = YatraPlanner;
